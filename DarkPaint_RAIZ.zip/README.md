# DarkPaint

Editor de dibujo digital para Android, hecho con Kotlin y Jetpack Compose. Nombre provisional.

> **Estado:** en desarrollo. El código de las Fases 1, 2 y 3 está escrito pero aún no se ha verificado que compile ni se ha probado en un dispositivo. Los resultados del workflow de GitHub Actions son la primera verificación.

## Qué incluye hoy

- Galería de dibujos con miniaturas, renombrar, duplicar, eliminar, búsqueda e importación de imágenes.
- Lienzo con zoom y desplazamiento con dos dedos.
- Pinceles: lápiz, pincel, pluma, aerógrafo, marcador y borrador, con tamaño, opacidad, suavizado y estabilizador.
- Presión del lápiz óptico cuando el dispositivo la reporta.
- Capas: crear, duplicar, renombrar, reordenar, mostrar/ocultar, bloquear, opacidad y combinar con la inferior. El número máximo depende de la memoria y del tamaño del lienzo.
- Deshacer y rehacer por mosaicos (trazos) y por operaciones (capas), con límite de memoria.
- Formato propio `.noche` versión 2 (ZIP con manifiesto, un PNG por capa y miniatura) con guardado seguro mediante archivo temporal. Los proyectos de la versión 1 se abren y se migran al guardar.
- Guardado automático cada 30 s y al salir de la app en una copia de recuperación aparte; si la app se cierra sin guardar, al abrir el dibujo se ofrece recuperarla.
- Exportación a PNG (con transparencia) y JPEG de la imagen compuesta de todas las capas visibles.

## Requisitos

- Android Studio reciente, JDK 17.
- `minSdk` 26, `compileSdk` y `targetSdk` 35.
- AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, Compose BOM 2024.10.01.

## Compilar

El repositorio no incluye `gradlew` ni `gradle-wrapper.jar`. Opciones:

1. Abrir la carpeta en Android Studio; descargará Gradle 8.9 por sí solo.
2. O ejecutar una vez `gradle wrapper --gradle-version 8.9` si tienes Gradle instalado.
3. O dejar que GitHub Actions lo compile: en la pestaña *Actions*, abre la última ejecución y descarga el artefacto `DarkPaint-debug-apk`.

```
gradle testDebugUnitTest assembleDebug
```

Las pruebas instrumentadas (`app/src/androidTest`) necesitan un dispositivo o emulador:

```
gradle connectedDebugAndroidTest
```

## Estructura

```
app/src/main/java/com/elnoche/studio/
  app/        MainActivity y navegación
  ui/         tema, galería, editor, paneles
  core/       modelo, motor de dibujo, historial, almacenamiento
  feature/    exportación e importación de imágenes
```

## Hoja de ruta

1. MVP funcional (hecho, sin verificar)
2. Experiencia de dibujo (hecho, sin verificar)
3. Documentos y capas (hecho, sin verificar)
4. Edición avanzada
5. Optimización y publicación

## Licencia

Pendiente de elegir. Hasta que se añada un archivo `LICENSE`, todos los derechos están reservados.

## Límites conocidos (Fase 3)

- Guardar y recuperar copian todas las capas en memoria un instante; en lienzos grandes con muchas capas puede faltar memoria y el guardado se cancela sin tocar el archivo anterior.
- Las capas no tienen miniatura propia en el panel todavía.
- No hay modos de fusión, grupos ni máscaras.
