# DarkPaint

Editor de dibujo digital para Android, hecho con Kotlin y Jetpack Compose. Nombre provisional.

> **Estado:** en desarrollo. El código de las Fases 1 y 2 está escrito pero aún no se ha verificado que compile ni se ha probado en un dispositivo. Los resultados del workflow de GitHub Actions son la primera verificación.

## Qué incluye hoy

- Galería de dibujos con miniaturas, renombrar, duplicar, eliminar, búsqueda e importación de imágenes.
- Lienzo con zoom y desplazamiento con dos dedos.
- Pinceles: lápiz, pincel, pluma, aerógrafo, marcador y borrador, con tamaño, opacidad, suavizado y estabilizador.
- Presión del lápiz óptico cuando el dispositivo la reporta.
- Deshacer y rehacer por mosaicos, con límite de memoria.
- Formato propio `.noche` (ZIP con manifiesto, capa PNG y miniatura) con guardado seguro mediante archivo temporal.
- Exportación a PNG (con transparencia) y JPEG.

## Requisitos

- Android Studio reciente, JDK 17.
- `minSdk` 26, `compileSdk` y `targetSdk` 35.
- AGP 8.7.3, Kotlin 2.0.21, Gradle 8.9, Compose BOM 2024.10.01.

## Compilar

El repositorio no incluye `gradlew` ni `gradle-wrapper.jar`. Opciones:

1. Abrir la carpeta en Android Studio; descargará Gradle 8.9 por sí solo.
2. O ejecutar una vez `gradle wrapper --gradle-version 8.9` si tienes Gradle instalado.
3. O dejar que GitHub Actions lo compile: en la pestaña *Actions*, abre la última ejecución y descarga el artefacto `DarkPaint-debug-apk`.

```
gradle testDebugUnitTest assembleDebug
```

Las pruebas instrumentadas (`app/src/androidTest`) necesitan un dispositivo o emulador:

```
gradle connectedDebugAndroidTest
```

## Estructura

```
app/src/main/java/com/elnoche/studio/
  app/        MainActivity y navegación
  ui/         tema, galería, editor, paneles
  core/       modelo, motor de dibujo, historial, almacenamiento
  feature/    exportación e importación de imágenes
```

## Hoja de ruta

1. MVP funcional (hecho, sin verificar)
2. Experiencia de dibujo (hecho, sin verificar)
3. Documentos y capas
4. Edición avanzada
5. Optimización y publicación

## Licencia

Pendiente de elegir. Hasta que se añada un archivo `LICENSE`, todos los derechos están reservados.
