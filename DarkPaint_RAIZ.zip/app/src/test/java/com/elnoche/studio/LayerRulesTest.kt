package com.elnoche.studio

import com.elnoche.studio.core.model.LayerRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class LayerRulesTest {

    @Test
    fun nextNameSkipsExistingNames() {
        assertEquals("Capa 1", LayerRules.nextName(emptyList()))
        assertEquals("Capa 3", LayerRules.nextName(listOf("Capa 1", "Capa 2")))
        assertEquals("Capa 3", LayerRules.nextName(listOf("Capa 2")))
    }

    @Test
    fun cleanNameTrimsAndLimitsLength() {
        assertEquals("hola", LayerRules.cleanName("  hola  "))
        assertEquals(LayerRules.MAX_NAME, LayerRules.cleanName("a".repeat(100)).length)
        assertEquals("", LayerRules.cleanName("   "))
    }

    @Test
    fun onlySafeLayerPathsAreAccepted() {
        assertTrue(LayerRules.isValidLayerFile("layers/layer0.png"))
        assertTrue(LayerRules.isValidLayerFile("layers/capa_1-a.png"))
        assertFalse(LayerRules.isValidLayerFile("../evil.png"))
        assertFalse(LayerRules.isValidLayerFile("layers/../x.png"))
        assertFalse(LayerRules.isValidLayerFile("layers/a/b.png"))
        assertFalse(LayerRules.isValidLayerFile("layers/x.jpg"))
        assertFalse(LayerRules.isValidLayerFile("/layers/x.png"))
    }

    @Test
    fun maxLayersDependsOnMemoryAndCanvasSize() {
        val mb256 = 256L * 1024 * 1024
        assertEquals(2, LayerRules.maxLayers(mb256, 4096, 4096))
        assertEquals(LayerRules.MAX_LAYERS_HARD, LayerRules.maxLayers(2 * mb256, 256, 256))
        assertEquals(1, LayerRules.maxLayers(16L * 1024 * 1024, 4096, 4096))
    }
}
