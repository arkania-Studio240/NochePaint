package com.elnoche.studio

import android.graphics.Color
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.elnoche.studio.core.drawing.BrushType
import com.elnoche.studio.core.drawing.DrawingEngine
import com.elnoche.studio.core.model.Layer
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class LayersTest {

    private fun alphaAt(l: Layer, x: Int, y: Int) = Color.alpha(l.bitmap.getPixel(x, y))

    private fun stroke(e: DrawingEngine, y: Float, type: BrushType = BrushType.BRUSH) {
        e.type = type
        e.size = 20f
        e.beginStroke(50f, y, 1f)
        e.moveStroke(150f, y, 1f)
        e.endStroke()
    }

    @Test
    fun addLayerSelectsItAndUndoRedoWork() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        assertEquals(1, e.layers.size)
        assertTrue(e.addLayer())
        assertEquals(2, e.layers.size)
        assertEquals(1, e.activeIndex)
        e.undo()
        assertEquals(1, e.layers.size)
        assertEquals(0, e.activeIndex)
        e.redo()
        assertEquals(2, e.layers.size)
        assertEquals(1, e.activeIndex)
    }

    @Test
    fun strokeOnlyAffectsActiveLayer() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        e.addLayer()
        stroke(e, 50f)
        assertTrue(alphaAt(e.layers[1], 100, 50) > 0)
        assertEquals(0, alphaAt(e.layers[0], 100, 50))
    }

    @Test
    fun eraserOnlyAffectsActiveLayer() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        stroke(e, 50f)
        e.addLayer()
        stroke(e, 50f)
        stroke(e, 50f, BrushType.ERASER)
        assertEquals(0, alphaAt(e.layers[1], 100, 50))
        assertTrue(alphaAt(e.layers[0], 100, 50) > 0)
    }

    @Test
    fun lockedOrHiddenLayerRejectsStrokes() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        e.setLocked(0, true)
        assertFalse(e.beginStroke(10f, 10f, 1f))
        e.setLocked(0, false)
        e.setVisible(0, false)
        assertFalse(e.beginStroke(10f, 10f, 1f))
        e.setVisible(0, true)
        assertTrue(e.beginStroke(10f, 10f, 1f))
        e.cancelStroke()
    }

    @Test
    fun lastLayerCannotBeRemoved() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        assertFalse(e.removeLayer())
        e.addLayer()
        assertTrue(e.removeLayer())
        assertEquals(1, e.layers.size)
        e.undo()
        assertEquals(2, e.layers.size)
    }

    @Test
    fun mergeDownCombinesAndCanBeUndone() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        stroke(e, 50f)
        e.addLayer()
        stroke(e, 150f)
        assertTrue(e.mergeDown())
        assertEquals(1, e.layers.size)
        assertTrue(alphaAt(e.layers[0], 100, 50) > 0)
        assertTrue(alphaAt(e.layers[0], 100, 150) > 0)
        e.undo()
        assertEquals(2, e.layers.size)
        assertEquals(0, alphaAt(e.layers[0], 100, 150))
        assertTrue(alphaAt(e.layers[1], 100, 150) > 0)
        e.redo()
        assertEquals(1, e.layers.size)
        assertTrue(alphaAt(e.layers[0], 100, 150) > 0)
    }

    @Test
    fun moveAndPropertyChangesAreUndoable() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        e.addLayer()
        val bottomId = e.layers[0].id
        assertTrue(e.moveActive(-1))
        assertEquals(bottomId, e.layers[1].id)
        e.undo()
        assertEquals(bottomId, e.layers[0].id)

        e.rename(0, "Fondo")
        assertEquals("Fondo", e.layers[0].name)
        e.undo()
        assertEquals("Capa 1", e.layers[0].name)

        e.previewOpacity(0, 0.4f)
        e.commitOpacity()
        assertEquals(0.4f, e.layers[0].opacity, 1e-4f)
        e.undo()
        assertEquals(1f, e.layers[0].opacity, 1e-4f)
    }

    @Test
    fun flattenSkipsHiddenLayers() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        stroke(e, 50f)
        val visible = e.flatten()
        assertTrue(Color.alpha(visible.getPixel(100, 50)) > 0)
        visible.recycle()
        e.setVisible(0, false)
        val hidden = e.flatten()
        assertEquals(0, Color.alpha(hidden.getPixel(100, 50)))
        hidden.recycle()
    }
}
