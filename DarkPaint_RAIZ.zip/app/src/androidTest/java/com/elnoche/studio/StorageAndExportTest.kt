package com.elnoche.studio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.elnoche.studio.core.drawing.BrushType
import com.elnoche.studio.core.drawing.DrawingEngine
import com.elnoche.studio.core.model.Layer
import com.elnoche.studio.core.storage.ProjectFormatException
import com.elnoche.studio.core.storage.ProjectStorage
import com.elnoche.studio.feature.export.ExportFormat
import com.elnoche.studio.feature.export.ImageExporter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

@RunWith(AndroidJUnit4::class)
class StorageAndExportTest {

    private val ctx = ApplicationProvider.getApplicationContext<Context>()
    private val storage = ProjectStorage(ctx)

    private fun bitmap(x: Int, y: Int, color: Int): Bitmap =
        Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).apply { setPixel(x, y, color) }

    private fun sampleLayers(): List<Layer> = listOf(
        Layer("a", "Fondo", bitmap(10, 10, Color.RED)),
        Layer("b", "Tinta", bitmap(20, 20, Color.BLUE), visible = false, opacity = 0.5f, locked = true)
    )

    @Test
    fun multiLayerProjectSurvivesSaveAndLoad() {
        val id = storage.newId()
        storage.save(id, "Prueba", 128, 128, -1, 1L, sampleLayers(), 1)
        val loaded = storage.load(storage.fileFor(id))
        assertEquals("Prueba", loaded.manifest.name)
        assertEquals(2, loaded.layers.size)
        assertEquals(1, loaded.manifest.activeLayer)
        assertEquals("Fondo", loaded.layers[0].name)
        assertEquals(Color.RED, loaded.layers[0].bitmap.getPixel(10, 10))
        assertEquals("Tinta", loaded.layers[1].name)
        assertEquals(Color.BLUE, loaded.layers[1].bitmap.getPixel(20, 20))
        assertFalse(loaded.layers[1].visible)
        assertTrue(loaded.layers[1].locked)
        assertEquals(0.5f, loaded.layers[1].opacity, 1e-3f)
        storage.delete(id)
    }

    @Test
    fun engineLayersRoundTripThroughStorage() {
        val e = DrawingEngine(128, 128, Color.WHITE)
        e.type = BrushType.BRUSH
        e.size = 20f
        e.beginStroke(30f, 30f, 1f)
        e.moveStroke(90f, 30f, 1f)
        e.endStroke()
        e.addLayer()
        e.setVisible(1, false)
        val snapshot = e.snapshotLayers()
        val id = storage.newId()
        storage.save(id, "Motor", 128, 128, Color.WHITE, 1L, snapshot, e.activeIndex)
        val loaded = storage.load(storage.fileFor(id))
        assertEquals(2, loaded.layers.size)
        assertTrue(Color.alpha(loaded.layers[0].bitmap.getPixel(60, 30)) > 0)
        assertFalse(loaded.layers[1].visible)
        assertEquals(1, loaded.manifest.activeLayer)
        storage.delete(id)
    }

    @Test
    fun renameAndDuplicateKeepAllLayers() {
        val id = storage.newId()
        storage.save(id, "Prueba", 128, 128, -1, 1L, sampleLayers(), 0)
        storage.copyWithName(id, id, "Nuevo")
        assertEquals("Nuevo", storage.load(storage.fileFor(id)).manifest.name)
        val copyId = storage.newId()
        storage.copyWithName(id, copyId, "Copia")
        val copy = storage.load(storage.fileFor(copyId))
        assertEquals("Copia", copy.manifest.name)
        assertEquals(2, copy.layers.size)
        storage.delete(id)
        storage.delete(copyId)
    }

    @Test
    fun recoveryCopyIsSeparateAndRemovedByNormalSave() {
        val id = storage.newId()
        storage.save(id, "Base", 128, 128, -1, 1L, sampleLayers(), 0)
        storage.save(id, "Base editada", 128, 128, -1, 1L, sampleLayers(), 0, recovery = true)
        assertTrue(storage.hasRecovery(id))
        assertEquals("Base", storage.load(storage.fileFor(id)).manifest.name)
        assertEquals("Base editada", storage.load(storage.recoveryFileFor(id)).manifest.name)
        storage.save(id, "Base", 128, 128, -1, 1L, sampleLayers(), 0)
        assertFalse(storage.hasRecovery(id))
        storage.delete(id)
    }

    @Test
    fun formatVersion1ProjectsStillOpen() {
        val id = storage.newId()
        val manifest = """{"formatVersion":1,"app":"NocheStudio","name":"Viejo","width":128,"height":128,"background":-1,"created":1,"modified":2,"layers":[{"id":"layer-1","name":"Capa 1","visible":true,"opacity":1.0,"file":"layers/layer0.png"}]}"""
        ZipOutputStream(storage.fileFor(id).outputStream()).use { zip ->
            zip.putNextEntry(ZipEntry("manifest.json"))
            zip.write(manifest.toByteArray(Charsets.UTF_8))
            zip.closeEntry()
            zip.putNextEntry(ZipEntry("layers/layer0.png"))
            bitmap(10, 10, Color.RED).compress(Bitmap.CompressFormat.PNG, 100, zip)
            zip.closeEntry()
        }
        val loaded = storage.load(storage.fileFor(id))
        assertEquals("Viejo", loaded.manifest.name)
        assertEquals(1, loaded.layers.size)
        assertEquals(Color.RED, loaded.layers[0].bitmap.getPixel(10, 10))
        storage.delete(id)
    }

    @Test(expected = ProjectFormatException::class)
    fun invalidFileIsRejectedAndKept() {
        val f = storage.fileFor("invalido-test")
        f.writeText("esto no es un zip")
        try {
            storage.load(f)
        } finally {
            assertTrue(f.exists())
            f.delete()
        }
    }

    @Test
    fun pngKeepsTransparencyAndJpegIsOpaque() {
        val png = File(ctx.cacheDir, "t.png")
        val jpg = File(ctx.cacheDir, "t.jpg")
        ImageExporter.write(ctx.contentResolver, Uri.fromFile(png), bitmap(10, 10, Color.RED), 0, ExportFormat.PNG)
        ImageExporter.write(ctx.contentResolver, Uri.fromFile(jpg), bitmap(10, 10, Color.RED), 0, ExportFormat.JPEG)
        assertEquals(0, Color.alpha(BitmapFactory.decodeFile(png.path).getPixel(50, 50)))
        assertEquals(255, Color.alpha(BitmapFactory.decodeFile(jpg.path).getPixel(50, 50)))
        png.delete()
        jpg.delete()
    }
}
