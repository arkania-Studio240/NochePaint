package com.elnoche.studio.ui.editor

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.elnoche.studio.R
import com.elnoche.studio.core.drawing.BrushType
import com.elnoche.studio.feature.export.ExportFormat
import com.elnoche.studio.feature.export.ImageExporter
import com.elnoche.studio.ui.panels.ColorPickerDialog
import kotlin.math.roundToInt

@Composable
fun EditorScreen(vm: EditorViewModel) {
    val doc = vm.engine ?: return
    var showColor by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var confirmExit by remember { mutableStateOf(false) }
    var showExport by remember { mutableStateOf(false) }
    var showLayers by remember { mutableStateOf(false) }
    val viewHolder = remember { arrayOfNulls<DrawingView>(1) }
    val pngLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/png")) { uri ->
        if (uri != null) vm.exportImage(uri, ExportFormat.PNG)
    }
    val jpgLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("image/jpeg")) { uri ->
        if (uri != null) vm.exportImage(uri, ExportFormat.JPEG)
    }

    fun requestExit() {
        if (vm.dirty) confirmExit = true else vm.closeEditor()
    }

    BackHandler { requestExit() }

    Column(Modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = { requestExit() }) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Volver a la galería")
            }
            Column(Modifier.weight(1f)) {
                Text(vm.projectName, style = MaterialTheme.typography.titleSmall, maxLines = 1)
                Text(
                    when {
                        vm.busy -> "Procesando…"
                        vm.dirty -> "Cambios sin guardar"
                        !vm.saved -> "Sin guardar"
                        else -> "Guardado"
                    },
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            IconButton(onClick = { vm.undo() }, enabled = vm.canUndo) {
                Icon(painterResource(R.drawable.ic_undo), contentDescription = "Deshacer")
            }
            IconButton(onClick = { vm.redo() }, enabled = vm.canRedo) {
                Icon(painterResource(R.drawable.ic_redo), contentDescription = "Rehacer")
            }
            TextButton(onClick = { vm.save() }, enabled = !vm.busy) { Text("Guardar") }
        }

        AndroidView(
            factory = { ctx ->
                DrawingView(ctx).apply {
                    onZoom = { vm.zoomPercent = it }
                    engine = doc
                    viewHolder[0] = this
                }
            },
            update = { it.engine = doc },
            modifier = Modifier.weight(1f).fillMaxWidth()
        )

        Column(
            Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            if (showLayers) LayersPanel(vm)
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BrushType.entries.forEach { b ->
                    FilterChip(
                        selected = vm.brush == b,
                        onClick = { vm.selectBrush(b) },
                        label = { Text(b.label) }
                    )
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(Color(vm.color))
                        .border(2.dp, MaterialTheme.colorScheme.outline, CircleShape)
                        .clickable(onClickLabel = "Elegir color") { showColor = true }
                )
                Slider(
                    value = vm.brushSize,
                    onValueChange = { vm.updateBrushSize(it) },
                    valueRange = 1f..120f,
                    modifier = Modifier.weight(1f).padding(horizontal = 8.dp)
                )
                Text("${vm.brushSize.toInt()} px", Modifier.width(52.dp), style = MaterialTheme.typography.labelMedium)
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = { showLayers = !showLayers }) {
                    Text(if (showLayers) "Ocultar capas" else "Capas")
                }
                TextButton(onClick = { showSettings = !showSettings }) {
                    Text(if (showSettings) "Ocultar" else "Ajustes")
                }
                Box {
                    TextButton(onClick = { showExport = true }, enabled = !vm.busy) { Text("Exportar") }
                    DropdownMenu(expanded = showExport, onDismissRequest = { showExport = false }) {
                        DropdownMenuItem(
                            text = { Text("PNG (conserva transparencia)") },
                            onClick = {
                                showExport = false
                                pngLauncher.launch(ImageExporter.suggestedName(vm.projectName, ExportFormat.PNG))
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("JPEG (fondo opaco)") },
                            onClick = {
                                showExport = false
                                jpgLauncher.launch(ImageExporter.suggestedName(vm.projectName, ExportFormat.JPEG))
                            }
                        )
                    }
                }
                Spacer(Modifier.weight(1f))
                TextButton(onClick = { viewHolder[0]?.fitToScreen() }) { Text("${vm.zoomPercent}%") }
            }
            if (showSettings) {
                SettingSlider("Opacidad", vm.opacity, 0.05f..1f) { vm.updateOpacity(it) }
                SettingSlider("Suavizado", vm.smoothing, 0f..1f) { vm.updateSmoothing(it) }
                SettingSlider("Estabilizador", vm.stabilization, 0f..1f) { vm.updateStabilization(it) }
            }
        }
    }

    if (showColor) {
        ColorPickerDialog(
            initial = vm.color,
            onDismiss = { showColor = false },
            onPick = { vm.updateColor(it); showColor = false }
        )
    }

    if (confirmExit) {
        AlertDialog(
            onDismissRequest = { confirmExit = false },
            title = { Text("¿Guardar los cambios?") },
            text = { Text("Este dibujo tiene cambios sin guardar.") },
            confirmButton = {
                TextButton(onClick = { confirmExit = false; vm.save(closeAfter = true) }) { Text("Guardar") }
            },
            dismissButton = {
                TextButton(onClick = { confirmExit = false; vm.closeEditor(discard = true) }) { Text("Descartar") }
            }
        )
    }
}

@Composable
private fun SettingSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(96.dp), style = MaterialTheme.typography.labelMedium)
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
        Text("${(value * 100).roundToInt()}%", Modifier.width(44.dp), style = MaterialTheme.typography.labelMedium)
    }
}
