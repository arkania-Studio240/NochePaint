package com.elnoche.studio.ui.editor

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.elnoche.studio.app.navigation.Screen
import com.elnoche.studio.core.drawing.DrawingEngine
import com.elnoche.studio.core.drawing.BrushType
import com.elnoche.studio.core.model.CanvasLimits
import com.elnoche.studio.core.model.ProjectSummary
import com.elnoche.studio.core.storage.ProjectFormatException
import com.elnoche.studio.core.storage.ProjectStorage
import com.elnoche.studio.feature.export.ExportFormat
import com.elnoche.studio.feature.export.ImageExporter
import com.elnoche.studio.feature.export.ImageImporter
import com.elnoche.studio.feature.export.ImportException
import com.elnoche.studio.core.model.Layer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val storage = ProjectStorage(app)

    var screen by mutableStateOf(Screen.GALLERY); private set
    var projects by mutableStateOf<List<ProjectSummary>>(emptyList()); private set
    var engine by mutableStateOf<DrawingEngine?>(null); private set
    var projectName by mutableStateOf(""); private set
    var brush by mutableStateOf(BrushType.BRUSH); private set
    var opacity by mutableFloatStateOf(1f); private set
    var smoothing by mutableFloatStateOf(0.2f); private set
    var stabilization by mutableFloatStateOf(0f); private set
    var color by mutableIntStateOf(Color.BLACK); private set
    var brushSize by mutableFloatStateOf(12f); private set
    var dirty by mutableStateOf(false); private set
    var saved by mutableStateOf(false); private set
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set
    var zoomPercent by mutableIntStateOf(100)
    var layerVersion by mutableIntStateOf(0); private set
    var recoveryPrompt by mutableStateOf<ProjectSummary?>(null); private set

    private var lastPaintBrush = BrushType.BRUSH
    private var projectId: String? = null
    private var created = 0L
    private var edits = 0
    private var recoveredAt = 0
    private var saveGen = 0
    private var recoverySaving = false
    private var autosaveJob: Job? = null
    private val writeMutex = Mutex()

    fun consumeMessage() {
        message = null
    }

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { storage.list() }
        }
    }

    fun createProject(width: Int, height: Int, background: Int) {
        CanvasLimits.validate(width, height)?.let { message = it; return }
        try {
            val name = "Dibujo " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
            attach(DrawingEngine(width, height, background), storage.newId(), name, System.currentTimeMillis(), false)
        } catch (e: OutOfMemoryError) {
            message = "Memoria insuficiente para crear un lienzo de ese tamaño."
        }
    }

    fun openProject(summary: ProjectSummary) {
        if (busy) return
        if (!summary.valid) {
            message = "Este archivo no es un proyecto válido. Se conserva sin cambios."
            return
        }
        if (summary.recoverable) {
            recoveryPrompt = summary
            return
        }
        loadProject(summary, fromRecovery = false)
    }

    fun resolveRecovery(recover: Boolean) {
        val summary = recoveryPrompt ?: return
        recoveryPrompt = null
        if (!recover) {
            viewModelScope.launch {
                withContext(Dispatchers.IO) { storage.discardRecovery(summary.id) }
                loadProject(summary, fromRecovery = false)
            }
        } else {
            loadProject(summary, fromRecovery = true)
        }
    }

    fun dismissRecoveryPrompt() {
        recoveryPrompt = null
    }

    private fun loadProject(summary: ProjectSummary, fromRecovery: Boolean) {
        if (busy) return
        busy = true
        viewModelScope.launch {
            try {
                val file = if (fromRecovery) storage.recoveryFileFor(summary.id) else storage.fileFor(summary.id)
                val loaded = withContext(Dispatchers.IO) { storage.load(file) }
                val m = loaded.manifest
                attach(
                    DrawingEngine(m.width, m.height, m.background, loaded.layers, m.activeLayer),
                    summary.id, m.name, m.created, true
                )
                if (fromRecovery) {
                    dirty = true
                    message = "Se recuperó la versión sin guardar"
                }
            } catch (e: ProjectFormatException) {
                message = "No se pudo abrir el dibujo: ${e.message}. El archivo original no se modificó."
            } catch (e: OutOfMemoryError) {
                message = "Memoria insuficiente para abrir este dibujo."
            } catch (e: Exception) {
                message = "No se pudo abrir el dibujo. El archivo original no se modificó."
            } finally {
                busy = false
            }
        }
    }

    private fun attach(e: DrawingEngine, id: String, name: String, createdAt: Long, alreadySaved: Boolean) {
        e.type = brush
        e.color = color
        e.size = brushSize
        e.opacity = opacity
        e.smoothing = smoothing
        e.stabilization = stabilization
        e.onChange = {
            edits++
            dirty = true
            canUndo = e.history.canUndo
            canRedo = e.history.canRedo
        }
        e.onSelection = { layerVersion++ }
        e.onNotice = { message = it }
        engine = e
        projectId = id
        projectName = name
        created = createdAt
        edits = 0
        dirty = false
        saved = alreadySaved
        canUndo = false
        canRedo = false
        zoomPercent = 100
        layerVersion++
        recoveredAt = 0
        screen = Screen.EDITOR
        startAutosave()
    }

    fun selectBrush(b: BrushType) {
        brush = b
        engine?.type = b
        if (!b.erases) lastPaintBrush = b
    }

    fun updateColor(c: Int) {
        color = c
        engine?.color = c
        if (brush.erases) selectBrush(lastPaintBrush)
    }

    fun updateOpacity(v: Float) {
        opacity = v
        engine?.opacity = v
    }

    fun updateSmoothing(v: Float) {
        smoothing = v
        engine?.smoothing = v
    }

    fun updateStabilization(v: Float) {
        stabilization = v
        engine?.stabilization = v
    }

    fun updateBrushSize(s: Float) {
        brushSize = s
        engine?.size = s
    }

    fun undo() {
        engine?.undo()
    }

    fun redo() {
        engine?.redo()
    }

    fun save(closeAfter: Boolean = false) {
        val e = engine ?: return
        val id = projectId ?: return
        if (busy) return
        busy = true
        val snapshot = try {
            e.snapshotLayers()
        } catch (oom: OutOfMemoryError) {
            null
        }
        if (snapshot == null) {
            busy = false
            message = "Memoria insuficiente para guardar."
            return
        }
        val captured = edits
        val name = projectName
        val active = e.activeIndex
        viewModelScope.launch {
            try {
                writeMutex.withLock {
                    withContext(Dispatchers.IO) {
                        storage.save(id, name, e.width, e.height, e.background, created, snapshot, active)
                    }
                    saveGen++
                }
                saved = true
                dirty = edits != captured
                message = "Guardado"
                if (closeAfter) closeEditor()
            } catch (t: Throwable) {
                message = "No se pudo guardar. La versión anterior sigue intacta."
            } finally {
                snapshot.forEach { it.bitmap.recycle() }
                busy = false
            }
        }
    }

    fun autosaveNow() {
        val e = engine ?: return
        val id = projectId ?: return
        if (!dirty || busy || recoverySaving || edits == recoveredAt || e.isDrawing) return
        val snapshot = try {
            e.snapshotLayers()
        } catch (oom: OutOfMemoryError) {
            return
        }
        val gen = saveGen
        val editsAt = edits
        val name = projectName
        val active = e.activeIndex
        recoverySaving = true
        viewModelScope.launch {
            try {
                writeMutex.withLock {
                    if (gen == saveGen) {
                        withContext(Dispatchers.IO) {
                            storage.save(id, name, e.width, e.height, e.background, created, snapshot, active, recovery = true)
                        }
                        recoveredAt = editsAt
                    }
                }
            } catch (t: Throwable) {
                // la copia de recuperación es opcional; el guardado manual sigue disponible
            } finally {
                snapshot.forEach { it.bitmap.recycle() }
                recoverySaving = false
            }
        }
    }

    private fun startAutosave() {
        autosaveJob?.cancel()
        autosaveJob = viewModelScope.launch {
            while (true) {
                delay(AUTOSAVE_MS)
                autosaveNow()
            }
        }
    }

    fun exportImage(uri: Uri, format: ExportFormat) {
        val e = engine ?: return
        if (busy) return
        busy = true
        val flat = try {
            e.flatten()
        } catch (oom: OutOfMemoryError) {
            null
        }
        if (flat == null) {
            busy = false
            message = "Memoria insuficiente para exportar."
            return
        }
        val resolver = getApplication<Application>().contentResolver
        val background = e.background
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { ImageExporter.write(resolver, uri, flat, background, format) }
                message = "Imagen exportada"
            } catch (t: Throwable) {
                message = "No se pudo exportar la imagen."
            } finally {
                flat.recycle()
                busy = false
            }
        }
    }

    fun importImage(uri: Uri) {
        if (busy) return
        busy = true
        val resolver = getApplication<Application>().contentResolver
        viewModelScope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) { ImageImporter.decode(resolver, uri) }
                val name = "Imagen " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
                val layer = Layer(Layer.newId(), "Imagen", bmp)
                attach(DrawingEngine(bmp.width, bmp.height, Color.WHITE, listOf(layer), 0), storage.newId(), name, System.currentTimeMillis(), false)
                dirty = true
            } catch (e: ImportException) {
                message = e.message
            } catch (e: OutOfMemoryError) {
                message = "Memoria insuficiente para importar esta imagen."
            } catch (e: Exception) {
                message = "No se pudo importar la imagen."
            } finally {
                busy = false
            }
        }
    }

    fun selectLayer(index: Int) {
        engine?.selectLayer(index)
    }

    fun addLayer() {
        engine?.addLayer()
    }

    fun duplicateLayer() {
        engine?.duplicateLayer()
    }

    fun deleteActiveLayer() {
        engine?.removeLayer()
    }

    fun moveActiveLayer(delta: Int) {
        engine?.moveActive(delta)
    }

    fun mergeActiveLayerDown() {
        engine?.mergeDown()
    }

    fun toggleLayerVisible(index: Int) {
        val e = engine ?: return
        e.layers.getOrNull(index)?.let { e.setVisible(index, !it.visible) }
    }

    fun toggleLayerLocked(index: Int) {
        val e = engine ?: return
        e.layers.getOrNull(index)?.let { e.setLocked(index, !it.locked) }
    }

    fun renameLayer(index: Int, name: String) {
        engine?.rename(index, name)
    }

    fun previewLayerOpacity(index: Int, value: Float) {
        engine?.previewOpacity(index, value)
    }

    fun commitLayerOpacity() {
        engine?.commitOpacity()
    }

    fun renameProject(p: ProjectSummary, newName: String) {
        val name = newName.trim().take(60)
        if (name.isEmpty()) {
            message = "El nombre no puede estar vacío."
            return
        }
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { storage.copyWithName(p.id, p.id, name) }
                refreshProjects()
            } catch (e: Exception) {
                message = "No se pudo renombrar. El archivo original no se modificó."
            }
        }
    }

    fun duplicateProject(p: ProjectSummary) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { storage.copyWithName(p.id, storage.newId(), "${p.name} (copia)".take(60)) }
                refreshProjects()
                message = "Dibujo duplicado"
            } catch (e: Exception) {
                message = "No se pudo duplicar el dibujo."
            }
        }
    }

    fun closeEditor(discard: Boolean = false) {
        val id = projectId
        autosaveJob?.cancel()
        autosaveJob = null
        engine?.release()
        engine = null
        projectId = null
        dirty = false
        screen = Screen.GALLERY
        if (discard && id != null) {
            viewModelScope.launch {
                writeMutex.withLock { withContext(Dispatchers.IO) { storage.discardRecovery(id) } }
                refreshProjects()
            }
        } else {
            refreshProjects()
        }
    }

    fun deleteProject(summary: ProjectSummary) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { storage.delete(summary.id) }
            refreshProjects()
        }
    }

    private companion object {
        const val AUTOSAVE_MS = 30_000L
    }
}
