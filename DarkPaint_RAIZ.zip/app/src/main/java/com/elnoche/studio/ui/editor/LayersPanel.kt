package com.elnoche.studio.ui.editor

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.elnoche.studio.R
import kotlin.math.roundToInt

@Composable
fun LayersPanel(vm: EditorViewModel) {
    val doc = vm.engine ?: return
    val version = vm.layerVersion
    val layers = doc.layers
    val active = doc.activeIndex
    var menuOpen by remember { mutableStateOf(false) }
    var renameIndex by remember { mutableStateOf<Int?>(null) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmMerge by remember { mutableStateOf(false) }
    var sliderValue by remember(version, active) { mutableFloatStateOf(doc.activeLayer.opacity) }

    Column(Modifier.fillMaxWidth().padding(bottom = 4.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Capas ${layers.size}/${doc.maxLayers}",
                Modifier.weight(1f).padding(start = 8.dp),
                style = MaterialTheme.typography.titleSmall
            )
            IconButton(onClick = { vm.addLayer() }) {
                Icon(Icons.Filled.Add, contentDescription = "Nueva capa")
            }
            Box {
                IconButton(onClick = { menuOpen = true }) {
                    Icon(Icons.Filled.MoreVert, contentDescription = "Acciones de la capa")
                }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    DropdownMenuItem(text = { Text("Renombrar") }, onClick = { menuOpen = false; renameIndex = active })
                    DropdownMenuItem(text = { Text("Duplicar") }, onClick = { menuOpen = false; vm.duplicateLayer() })
                    DropdownMenuItem(
                        text = { Text("Subir") },
                        enabled = active < layers.lastIndex,
                        onClick = { menuOpen = false; vm.moveActiveLayer(1) }
                    )
                    DropdownMenuItem(
                        text = { Text("Bajar") },
                        enabled = active > 0,
                        onClick = { menuOpen = false; vm.moveActiveLayer(-1) }
                    )
                    DropdownMenuItem(
                        text = { Text("Combinar con la inferior") },
                        enabled = active > 0,
                        onClick = { menuOpen = false; confirmMerge = true }
                    )
                    DropdownMenuItem(
                        text = { Text("Eliminar") },
                        enabled = layers.size > 1,
                        onClick = { menuOpen = false; confirmDelete = true }
                    )
                }
            }
        }

        Column(Modifier.heightIn(max = 168.dp).verticalScroll(rememberScrollState())) {
            for (i in layers.indices.reversed()) {
                val layer = layers[i]
                val selected = i == active
                Row(
                    Modifier.fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (selected) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                        .clickable { vm.selectLayer(i) },
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { vm.toggleLayerVisible(i) }) {
                        Icon(
                            painterResource(if (layer.visible) R.drawable.ic_eye else R.drawable.ic_eye_off),
                            contentDescription = if (layer.visible) "Ocultar ${layer.name}" else "Mostrar ${layer.name}"
                        )
                    }
                    Text(layer.name, Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(
                        "${(layer.opacity * 100).roundToInt()}%",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    IconButton(onClick = { vm.toggleLayerLocked(i) }) {
                        Icon(
                            Icons.Filled.Lock,
                            contentDescription = if (layer.locked) "Desbloquear ${layer.name}" else "Bloquear ${layer.name}",
                            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = if (layer.locked) 1f else 0.3f)
                        )
                    }
                }
            }
        }

        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(horizontal = 8.dp)) {
            Text("Opacidad", Modifier.width(80.dp), style = MaterialTheme.typography.labelMedium)
            Slider(
                value = sliderValue,
                onValueChange = {
                    sliderValue = it
                    vm.previewLayerOpacity(active, it)
                },
                onValueChangeFinished = { vm.commitLayerOpacity() },
                valueRange = 0f..1f,
                modifier = Modifier.weight(1f)
            )
            Text("${(sliderValue * 100).roundToInt()}%", Modifier.width(44.dp), style = MaterialTheme.typography.labelMedium)
        }
    }

    renameIndex?.let { index ->
        var text by remember(index) { mutableStateOf(layers.getOrNull(index)?.name ?: "") }
        AlertDialog(
            onDismissRequest = { renameIndex = null },
            title = { Text("Renombrar capa") },
            text = {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it.take(40) },
                    singleLine = true
                )
            },
            confirmButton = {
                TextButton(onClick = { vm.renameLayer(index, text); renameIndex = null }) { Text("Aceptar") }
            },
            dismissButton = { TextButton(onClick = { renameIndex = null }) { Text("Cancelar") } }
        )
    }

    if (confirmDelete) {
        AlertDialog(
            onDismissRequest = { confirmDelete = false },
            title = { Text("¿Eliminar capa?") },
            text = { Text("Se eliminará «${doc.activeLayer.name}». Puedes deshacerlo mientras no cierres el dibujo.") },
            confirmButton = {
                TextButton(onClick = { confirmDelete = false; vm.deleteActiveLayer() }) { Text("Eliminar") }
            },
            dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancelar") } }
        )
    }

    if (confirmMerge) {
        AlertDialog(
            onDismissRequest = { confirmMerge = false },
            title = { Text("¿Combinar con la inferior?") },
            text = { Text("«${doc.activeLayer.name}» se fusionará con la capa de abajo. Puedes deshacerlo.") },
            confirmButton = {
                TextButton(onClick = { confirmMerge = false; vm.mergeActiveLayerDown() }) { Text("Combinar") }
            },
            dismissButton = { TextButton(onClick = { confirmMerge = false }) { Text("Cancelar") } }
        )
    }
}
