package com.elnoche.studio.core.model

object LayerRules {
    const val MAX_LAYERS_HARD = 24
    const val MAX_NAME = 40

    private val FILE_PATTERN = Regex("^layers/[A-Za-z0-9_-]{1,64}\\.png$")

    fun isValidLayerFile(path: String): Boolean = FILE_PATTERN.matches(path)

    fun nextName(existing: List<String>): String {
        var n = existing.size + 1
        while (existing.contains("Capa $n")) n++
        return "Capa $n"
    }

    fun cleanName(raw: String): String = raw.trim().take(MAX_NAME)

    fun maxLayers(maxMemoryBytes: Long, width: Int, height: Int): Int {
        val layerBytes = width.toLong() * height * 4L
        if (layerBytes <= 0L) return 1
        val budget = (maxMemoryBytes * 0.5).toLong()
        return (budget / layerBytes).toInt().coerceIn(1, MAX_LAYERS_HARD)
    }
}
