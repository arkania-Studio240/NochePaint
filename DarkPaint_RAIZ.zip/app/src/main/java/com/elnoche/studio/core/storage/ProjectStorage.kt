package com.elnoche.studio.core.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import com.elnoche.studio.core.model.CanvasLimits
import com.elnoche.studio.core.model.Layer
import com.elnoche.studio.core.model.LayerRules
import com.elnoche.studio.core.model.ProjectSummary
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipException
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream
import kotlin.math.roundToInt

class ProjectFormatException(message: String) : Exception(message)

data class LayerInfo(
    val id: String,
    val name: String,
    val visible: Boolean,
    val opacity: Float,
    val locked: Boolean,
    val file: String
)

data class Manifest(
    val formatVersion: Int,
    val name: String,
    val width: Int,
    val height: Int,
    val background: Int,
    val created: Long,
    val modified: Long,
    val activeLayer: Int,
    val layers: List<LayerInfo>
)

class LoadedProject(val manifest: Manifest, val layers: List<Layer>)

class ProjectStorage(context: Context) {

    private val dir = File(context.filesDir, "projects").apply { mkdirs() }

    fun newId(): String = UUID.randomUUID().toString()

    fun fileFor(id: String) = File(dir, "$id.noche")

    fun recoveryFileFor(id: String) = File(dir, "$id.recovery")

    fun hasRecovery(id: String): Boolean = recoveryFileFor(id).isFile

    fun discardRecovery(id: String) {
        recoveryFileFor(id).delete()
    }

    fun save(
        id: String,
        name: String,
        width: Int,
        height: Int,
        background: Int,
        created: Long,
        layers: List<Layer>,
        activeIndex: Int,
        recovery: Boolean = false
    ) {
        require(layers.isNotEmpty()) { "Se necesita al menos una capa" }
        val target = if (recovery) recoveryFileFor(id) else fileFor(id)
        val tmp = File(dir, target.name + ".tmp")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zip ->
                zip.putNextEntry(ZipEntry(MANIFEST))
                zip.write(buildManifest(name, width, height, background, created, layers, activeIndex).toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                layers.forEachIndexed { i, layer ->
                    zip.putNextEntry(ZipEntry(layerPath(i)))
                    layer.bitmap.compress(Bitmap.CompressFormat.PNG, 100, zip)
                    zip.closeEntry()
                }
                zip.putNextEntry(ZipEntry(THUMB))
                makeThumb(layers, width, height, background).also {
                    it.compress(Bitmap.CompressFormat.PNG, 100, zip)
                    it.recycle()
                }
                zip.closeEntry()
            }
            ZipFile(tmp).use { zf ->
                val m = readManifest(zf)
                for (info in m.layers) {
                    val e = zf.getEntry(info.file)
                    if (e == null || e.size <= 0) throw ProjectFormatException("Guardado incompleto")
                }
            }
            commit(tmp, target)
            if (!recovery) recoveryFileFor(id).delete()
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }

    fun copyWithName(srcId: String, dstId: String, newName: String) {
        val tmp = File(dir, "$dstId.noche.tmp")
        try {
            ZipFile(fileFor(srcId)).use { zf ->
                readManifest(zf)
                val entry = zf.getEntry(MANIFEST)!!
                val json = JSONObject(zf.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) })
                val now = System.currentTimeMillis()
                json.put("name", newName)
                json.put("modified", now)
                if (srcId != dstId) json.put("created", now)
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST))
                    zip.write(json.toString().toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    for (e in zf.entries()) {
                        if (e.name == MANIFEST || e.isDirectory) continue
                        zip.putNextEntry(ZipEntry(e.name))
                        zf.getInputStream(e).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            ZipFile(tmp).use { readManifest(it) }
            commit(tmp, fileFor(dstId))
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }

    private fun commit(tmp: File, target: File) {
        try {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } catch (e: AtomicMoveNotSupportedException) {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    fun load(file: File): LoadedProject {
        try {
            ZipFile(file).use { zf ->
                val m = readManifest(zf)
                val layers = ArrayList<Layer>()
                try {
                    for (info in m.layers) {
                        val entry = zf.getEntry(info.file)
                            ?: throw ProjectFormatException("Falta el contenido de la capa \"${info.name}\"")
                        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                        zf.getInputStream(entry).use { BitmapFactory.decodeStream(it, null, bounds) }
                        if (bounds.outWidth != m.width || bounds.outHeight != m.height) {
                            throw ProjectFormatException("Las dimensiones de la capa \"${info.name}\" no coinciden")
                        }
                        val opts = BitmapFactory.Options().apply {
                            inMutable = true
                            inPreferredConfig = Bitmap.Config.ARGB_8888
                        }
                        val bmp = zf.getInputStream(entry).use { BitmapFactory.decodeStream(it, null, opts) }
                            ?: throw ProjectFormatException("La imagen de la capa \"${info.name}\" está dañada")
                        layers.add(Layer(info.id, info.name, bmp, info.visible, info.opacity, info.locked))
                    }
                } catch (t: Throwable) {
                    layers.forEach { it.bitmap.recycle() }
                    throw t
                }
                return LoadedProject(m, layers)
            }
        } catch (e: ZipException) {
            throw ProjectFormatException("El archivo no es un proyecto válido")
        }
    }

    fun list(): List<ProjectSummary> {
        cleanup()
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".noche") } ?: return emptyList()
        return files.map { f ->
            val id = f.name.removeSuffix(".noche")
            try {
                ZipFile(f).use { zf ->
                    val m = readManifest(zf)
                    val thumb = zf.getEntry(THUMB)?.let { e ->
                        zf.getInputStream(e).use { BitmapFactory.decodeStream(it) }
                    }
                    ProjectSummary(id, m.name, m.width, m.height, m.modified, thumb, true, hasRecovery(id))
                }
            } catch (e: Exception) {
                ProjectSummary(id, "Archivo no válido", 0, 0, f.lastModified(), null, false, false)
            }
        }.sortedByDescending { it.modified }
    }

    fun delete(id: String) {
        fileFor(id).delete()
        recoveryFileFor(id).delete()
    }

    private fun cleanup() {
        val now = System.currentTimeMillis()
        dir.listFiles()?.forEach { f ->
            if (f.isFile && f.name.endsWith(".tmp") && now - f.lastModified() > STALE_TMP_MS) f.delete()
        }
        dir.listFiles { f -> f.isFile && f.name.endsWith(".recovery") }?.forEach { rec ->
            val id = rec.name.removeSuffix(".recovery")
            if (fileFor(id).exists()) return@forEach
            try {
                ZipFile(rec).use { readManifest(it) }
                commit(rec, fileFor(id))
            } catch (e: Exception) {
                // se conserva el archivo sin tocar
            }
        }
    }

    private fun layerPath(i: Int) = "layers/layer$i.png"

    private fun buildManifest(
        name: String,
        width: Int,
        height: Int,
        background: Int,
        created: Long,
        layers: List<Layer>,
        activeIndex: Int
    ): JSONObject = JSONObject().apply {
        put("formatVersion", FORMAT_VERSION)
        put("app", "DarkPaint")
        put("name", name)
        put("width", width)
        put("height", height)
        put("background", background)
        put("created", created)
        put("modified", System.currentTimeMillis())
        put("activeLayer", activeIndex.coerceIn(0, layers.size - 1))
        put("layers", JSONArray().also { arr ->
            layers.forEachIndexed { i, l ->
                arr.put(JSONObject().apply {
                    put("id", l.id)
                    put("name", l.name)
                    put("visible", l.visible)
                    put("opacity", l.opacity.toDouble())
                    put("locked", l.locked)
                    put("file", layerPath(i))
                })
            }
        })
    }

    private fun readManifest(zf: ZipFile): Manifest {
        val entry = zf.getEntry(MANIFEST) ?: throw ProjectFormatException("Falta el manifiesto")
        if (entry.size <= 0 || entry.size > 1_000_000) throw ProjectFormatException("Manifiesto inválido")
        val text = zf.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
        try {
            val o = JSONObject(text)
            val version = o.getInt("formatVersion")
            if (version < 1) throw ProjectFormatException("Versión de formato inválida")
            if (version > FORMAT_VERSION) throw ProjectFormatException("Creado con una versión más nueva de la app")
            val w = o.getInt("width")
            val h = o.getInt("height")
            CanvasLimits.validate(w, h)?.let { throw ProjectFormatException(it) }
            val arr = o.getJSONArray("layers")
            if (arr.length() < 1) throw ProjectFormatException("El proyecto no tiene capas")
            if (arr.length() > LayerRules.MAX_LAYERS_HARD * 2) throw ProjectFormatException("Demasiadas capas")
            val seen = HashSet<String>()
            val infos = ArrayList<LayerInfo>()
            for (i in 0 until arr.length()) {
                val lo = arr.getJSONObject(i)
                val file = lo.getString("file")
                if (!LayerRules.isValidLayerFile(file)) throw ProjectFormatException("Ruta de capa inválida")
                var id = lo.optString("id", "").take(64)
                if (id.isEmpty() || !seen.add(id)) {
                    id = Layer.newId()
                    seen.add(id)
                }
                infos.add(
                    LayerInfo(
                        id,
                        lo.optString("name", "Capa ${i + 1}").take(LayerRules.MAX_NAME),
                        lo.optBoolean("visible", true),
                        lo.optDouble("opacity", 1.0).toFloat().coerceIn(0f, 1f),
                        lo.optBoolean("locked", false),
                        file
                    )
                )
            }
            val active = o.optInt("activeLayer", 0).coerceIn(0, infos.size - 1)
            return Manifest(
                version, o.optString("name", "Sin nombre"), w, h,
                o.optInt("background", -1), o.optLong("created", 0L), o.optLong("modified", 0L),
                active, infos
            )
        } catch (e: JSONException) {
            throw ProjectFormatException("Manifiesto ilegible")
        }
    }

    private fun makeThumb(layers: List<Layer>, width: Int, height: Int, background: Int): Bitmap {
        val ratio = THUMB_MAX.toFloat() / maxOf(width, height)
        val tw = maxOf(1, (width * ratio).toInt())
        val th = maxOf(1, (height * ratio).toInt())
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(if ((background ushr 24) == 0) 0xFFDDDDDD.toInt() else background)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG)
        val dst = Rect(0, 0, tw, th)
        for (l in layers) {
            if (!l.visible) continue
            paint.alpha = (l.opacity * 255f).roundToInt().coerceIn(0, 255)
            c.drawBitmap(l.bitmap, null, dst, paint)
        }
        return out
    }

    companion object {
        const val FORMAT_VERSION = 2
        private const val MANIFEST = "manifest.json"
        private const val THUMB = "thumb.png"
        private const val THUMB_MAX = 256
        private const val STALE_TMP_MS = 10L * 60L * 1000L
    }
}
