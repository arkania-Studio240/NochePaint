package com.elnoche.studio.ui.gallery

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.elnoche.studio.core.model.CanvasLimits
import com.elnoche.studio.core.model.ProjectSummary
import com.elnoche.studio.ui.editor.EditorViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GalleryScreen(vm: EditorViewModel) {
    var showNew by remember { mutableStateOf(false) }
    var toDelete by remember { mutableStateOf<ProjectSummary?>(null) }
    var toRename by remember { mutableStateOf<ProjectSummary?>(null) }
    var query by remember { mutableStateOf("") }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.importImage(uri)
    }
    val shown = vm.projects.filter { it.name.contains(query.trim(), ignoreCase = true) }

    LaunchedEffect(Unit) { vm.refreshProjects() }

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("DarkPaint", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.weight(1f))
                TextButton(onClick = { importLauncher.launch(arrayOf("image/*")) }, enabled = !vm.busy) {
                    Text("Importar imagen")
                }
            }
            if (vm.projects.size > 8) {
                OutlinedTextField(
                    value = query, onValueChange = { query = it },
                    label = { Text("Buscar") }, singleLine = true, modifier = Modifier.fillMaxWidth()
                )
            }
            Spacer(Modifier.height(12.dp))
            if (shown.isEmpty()) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(
                        if (vm.projects.isEmpty()) "Todavía no tienes dibujos.\nCrea el primero." else "Sin resultados.",
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center
                    )
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(160.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 88.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(shown, key = { it.id }) { p ->
                        ProjectCard(
                            p,
                            onOpen = { vm.openProject(p) },
                            onRename = { toRename = p },
                            onDuplicate = { vm.duplicateProject(p) },
                            onDelete = { toDelete = p }
                        )
                    }
                }
            }
        }
        ExtendedFloatingActionButton(
            onClick = { showNew = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Text("Nuevo dibujo") }
    }

    if (showNew) {
        NewCanvasDialog(
            onDismiss = { showNew = false },
            onCreate = { w, h, bg -> showNew = false; vm.createProject(w, h, bg) }
        )
    }

    toDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { toDelete = null },
            title = { Text("¿Eliminar dibujo?") },
            text = { Text("«${p.name}» se eliminará de forma permanente.") },
            confirmButton = { TextButton(onClick = { toDelete = null; vm.deleteProject(p) }) { Text("Eliminar") } },
            dismissButton = { TextButton(onClick = { toDelete = null }) { Text("Cancelar") } }
        )
    }

    toRename?.let { p ->
        RenameDialog(p, onDismiss = { toRename = null }, onConfirm = { toRename = null; vm.renameProject(p, it) })
    }
}

@Composable
private fun ProjectCard(
    p: ProjectSummary,
    onOpen: () -> Unit,
    onRename: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit
) {
    var menu by remember { mutableStateOf(false) }
    Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).background(Color(0xFF0E0E10)).clickable { onOpen() },
            contentAlignment = Alignment.Center
        ) {
            val thumb = p.thumb
            if (thumb != null) {
                val img = remember(thumb) { thumb.asImageBitmap() }
                Image(img, contentDescription = p.name, contentScale = ContentScale.Fit, modifier = Modifier.fillMaxSize())
            } else {
                Text("Sin vista previa", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        Column(Modifier.padding(start = 10.dp, end = 10.dp, top = 8.dp)) {
            Text(p.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
            val date = SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(p.modified))
            Text(
                if (p.valid) "${p.width}×${p.height} · $date" else "No se puede abrir",
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Box {
                TextButton(onClick = { menu = true }) { Text("Opciones") }
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    if (p.valid) {
                        DropdownMenuItem(text = { Text("Renombrar") }, onClick = { menu = false; onRename() })
                        DropdownMenuItem(text = { Text("Duplicar") }, onClick = { menu = false; onDuplicate() })
                    }
                    DropdownMenuItem(text = { Text("Eliminar") }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

private data class Preset(val label: String, val w: Int, val h: Int)

private val PRESETS = listOf(
    Preset("Cuadrado 2048×2048", 2048, 2048),
    Preset("Vertical 1080×1920", 1080, 1920),
    Preset("Horizontal 1920×1080", 1920, 1080),
    Preset("A4 300 ppp 2480×3508", 2480, 3508)
)

@Composable
private fun NewCanvasDialog(onDismiss: () -> Unit, onCreate: (Int, Int, Int) -> Unit) {
    var w by remember { mutableStateOf("2048") }
    var h by remember { mutableStateOf("2048") }
    var transparent by remember { mutableStateOf(false) }
    val wi = w.toIntOrNull()
    val hi = h.toIntOrNull()
    val error = if (wi == null || hi == null) "Introduce números válidos." else CanvasLimits.validate(wi, hi)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nuevo dibujo") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PRESETS.forEach { p ->
                    FilterChip(
                        selected = w == p.w.toString() && h == p.h.toString(),
                        onClick = { w = p.w.toString(); h = p.h.toString() },
                        label = { Text(p.label) }
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = w, onValueChange = { w = it.filter(Char::isDigit).take(5) },
                        label = { Text("Ancho") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                    OutlinedTextField(
                        value = h, onValueChange = { h = it.filter(Char::isDigit).take(5) },
                        label = { Text("Alto") }, singleLine = true, modifier = Modifier.weight(1f),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !transparent, onClick = { transparent = false }, label = { Text("Fondo blanco") })
                    FilterChip(selected = transparent, onClick = { transparent = true }, label = { Text("Transparente") })
                }
                if (error != null) Text(error, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelMedium)
            }
        },
        confirmButton = {
            TextButton(
                enabled = error == null,
                onClick = { onCreate(wi!!, hi!!, if (transparent) 0 else 0xFFFFFFFF.toInt()) }
            ) { Text("Crear") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun RenameDialog(p: ProjectSummary, onDismiss: () -> Unit, onConfirm: (String) -> Unit) {
    var text by remember { mutableStateOf(p.name) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Renombrar dibujo") },
        text = {
            OutlinedTextField(
                value = text, onValueChange = { text = it.take(60) },
                label = { Text("Nombre") }, singleLine = true
            )
        },
        confirmButton = { TextButton(enabled = text.isNotBlank(), onClick = { onConfirm(text) }) { Text("Guardar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}
