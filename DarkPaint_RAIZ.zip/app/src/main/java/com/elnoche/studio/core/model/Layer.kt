package com.elnoche.studio.core.model

import android.graphics.Bitmap
import android.graphics.Canvas
import java.util.UUID

data class LayerProps(
    val name: String,
    val visible: Boolean,
    val opacity: Float,
    val locked: Boolean
)

class Layer(
    val id: String,
    var name: String,
    val bitmap: Bitmap,
    var visible: Boolean = true,
    var opacity: Float = 1f,
    var locked: Boolean = false
) {
    val canvas: Canvas by lazy { Canvas(bitmap) }

    fun props() = LayerProps(name, visible, opacity, locked)

    fun assign(p: LayerProps) {
        name = p.name
        visible = p.visible
        opacity = p.opacity
        locked = p.locked
    }

    fun copy(newId: String, newName: String): Layer =
        Layer(newId, newName, bitmap.copy(Bitmap.Config.ARGB_8888, true), visible, opacity, locked)

    companion object {
        fun newId(): String = UUID.randomUUID().toString()

        fun blank(id: String, name: String, width: Int, height: Int): Layer =
            Layer(id, name, Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888))
    }
}
