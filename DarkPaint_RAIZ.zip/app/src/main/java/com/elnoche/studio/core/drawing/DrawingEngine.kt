package com.elnoche.studio.core.drawing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import com.elnoche.studio.core.history.History
import com.elnoche.studio.core.history.HistoryEntry
import com.elnoche.studio.core.model.Layer
import com.elnoche.studio.core.model.LayerProps
import com.elnoche.studio.core.model.LayerRules
import com.elnoche.studio.core.model.ViewTransform
import com.elnoche.studio.core.rendering.Compositor
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class TilePair(val x: Int, val y: Int, val before: Bitmap, val after: Bitmap)

class StrokePatch(val layerId: String, val tiles: List<TilePair>) : HistoryEntry {
    override val sizeBytes: Long = tiles.sumOf { it.before.byteCount.toLong() + it.after.byteCount.toLong() }
}

class LayerAddEntry(
    val layer: Layer,
    val index: Int,
    val activeBefore: Int,
    val activeAfter: Int
) : HistoryEntry {
    override val sizeBytes: Long = 0L
}

class LayerRemoveEntry(
    val layer: Layer,
    val index: Int,
    val activeBefore: Int,
    val activeAfter: Int
) : HistoryEntry {
    override val sizeBytes: Long = layer.bitmap.byteCount.toLong()
}

class LayerMoveEntry(
    val from: Int,
    val to: Int,
    val activeBefore: Int,
    val activeAfter: Int
) : HistoryEntry {
    override val sizeBytes: Long = 0L
}

class LayerPropsEntry(
    val layerId: String,
    val before: LayerProps,
    val after: LayerProps
) : HistoryEntry {
    override val sizeBytes: Long = 0L
}

class LayerMergeEntry(
    val removed: Layer,
    val removedIndex: Int,
    val lowerId: String,
    val lowerBefore: Bitmap,
    val activeBefore: Int,
    val activeAfter: Int
) : HistoryEntry {
    override val sizeBytes: Long = removed.bitmap.byteCount.toLong() + lowerBefore.byteCount.toLong()
}

class DrawingEngine(
    val width: Int,
    val height: Int,
    val background: Int,
    initialLayers: List<Layer>? = null,
    initialActive: Int = 0
) {
    private val layerList = ArrayList<Layer>()

    init {
        if (initialLayers.isNullOrEmpty()) {
            layerList.add(Layer.blank(Layer.newId(), "Capa 1", width, height))
        } else {
            layerList.addAll(initialLayers)
        }
    }

    val layers: List<Layer> get() = layerList
    var activeIndex: Int = initialActive.coerceIn(0, layerList.size - 1)
        private set
    val activeLayer: Layer get() = layerList[activeIndex]
    val bitmap: Bitmap get() = layerList[activeIndex].bitmap
    val maxLayers: Int = LayerRules.maxLayers(Runtime.getRuntime().maxMemory(), width, height)
    val history = History()
    val transform = ViewTransform()

    var viewW = 0
    var viewH = 0
    var type = BrushType.BRUSH
    var color = Color.BLACK
    var size = 12f
    var opacity = 1f
    var smoothing: Float
        get() = filter.smoothing
        set(v) { filter.smoothing = v.coerceIn(0f, 1f) }
    var stabilization: Float
        get() = filter.stabilization
        set(v) { filter.stabilization = v.coerceIn(0f, 1f) }

    var onChange: (() -> Unit)? = null
    var onSelection: (() -> Unit)? = null
    var onNotice: ((String) -> Unit)? = null
    var redraw: (() -> Unit)? = null

    val isDrawing: Boolean get() = active
    val liveBuffer: Bitmap? get() = if (active && !direct) strokeBuf else null
    var liveAlpha = 255
        private set

    private val filter = StrokeFilter()
    private var strokeLayer: Layer = layerList[activeIndex]
    private var strokeBuf: Bitmap? = null
    private var strokeCanvas: Canvas? = null
    private var bufferFailed = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val softPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val compositePaint = Paint()
    private val copyPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private val cols = (width + TILE - 1) / TILE

    private var saved: HashMap<Long, Bitmap>? = null
    private var active = false
    private var direct = false
    private var target: Canvas = layerList[activeIndex].canvas
    private var cur = BrushType.BRUSH
    private var curSize = 12f
    private var pendingOpacity: Pair<String, LayerProps>? = null

    private var lastX = 0f
    private var lastY = 0f
    private var lastW = 0f
    private var midX = 0f
    private var midY = 0f
    private var midW = 0f
    private var dl = 0f
    private var dt = 0f
    private var dr = 0f
    private var db = 0f

    fun beginStroke(x: Float, y: Float, pressure: Float): Boolean {
        if (active) return false
        val layer = layerList[activeIndex]
        if (!layer.visible) {
            onNotice?.invoke("La capa activa está oculta.")
            return false
        }
        if (layer.locked) {
            onNotice?.invoke("La capa activa está bloqueada.")
            return false
        }
        strokeLayer = layer
        cur = type
        curSize = size
        liveAlpha = (opacity * cur.opacityScale * 255f).roundToInt().coerceIn(1, 255)
        ensureBuffer()
        direct = cur.erases || strokeBuf == null
        target = if (direct) layer.canvas else strokeCanvas!!
        saved = HashMap()
        active = true
        dl = Float.MAX_VALUE; dt = Float.MAX_VALUE; dr = -Float.MAX_VALUE; db = -Float.MAX_VALUE

        val rgb = color and 0x00FFFFFF
        val paintAlpha = if (direct && !cur.erases) liveAlpha else 255
        paint.color = rgb or (paintAlpha shl 24)
        paint.xfermode = if (cur.erases) clearMode else null
        paint.strokeCap = if (cur.square) Paint.Cap.SQUARE else Paint.Cap.ROUND
        if (cur.soft) {
            val flow = (0.06f * paintAlpha).roundToInt().coerceAtLeast(1)
            val c0 = rgb or (flow shl 24)
            softPaint.shader = RadialGradient(
                0f, 0f, 1f, intArrayOf(c0, c0, rgb), floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP
            )
        }

        filter.start(x, y, pressure)
        val w = cur.widthFor(curSize, pressure)
        stamp(x, y, w)
        lastX = x; lastY = y; lastW = w
        midX = x; midY = y; midW = w
        return true
    }

    fun moveStroke(x: Float, y: Float, pressure: Float) {
        if (!active) return
        if (filter.add(x, y, pressure, transform.scale)) addPoint(filter.outX, filter.outY, filter.outP)
    }

    fun endStroke() {
        if (!active) return
        filter.flush()
        addPoint(filter.outX, filter.outY, filter.outP)
        curve(midX, midY, lastX, lastY, lastX, lastY, midW, lastW)

        if (!direct) {
            dirtyRect()?.let { rect ->
                saveTiles(rect.left.toFloat(), rect.top.toFloat(), rect.right.toFloat(), rect.bottom.toFloat())
                compositePaint.alpha = liveAlpha
                strokeLayer.canvas.drawBitmap(strokeBuf!!, rect, rect, compositePaint)
                clearBuffer(rect)
            }
        }

        val before = saved ?: HashMap()
        val src = strokeLayer.bitmap
        val tiles = before.map { (key, bmp) ->
            val px = (key % cols).toInt() * TILE
            val py = (key / cols).toInt() * TILE
            TilePair(px, py, bmp, Bitmap.createBitmap(src, px, py, bmp.width, bmp.height))
        }
        saved = null
        active = false
        if (tiles.isNotEmpty()) {
            history.push(StrokePatch(strokeLayer.id, tiles))
            onChange?.invoke()
        }
    }

    fun cancelStroke() {
        if (!active) return
        if (direct) {
            saved?.forEach { (key, bmp) ->
                val px = (key % cols).toInt() * TILE
                val py = (key / cols).toInt() * TILE
                strokeLayer.canvas.drawBitmap(bmp, px.toFloat(), py.toFloat(), copyPaint)
            }
        } else {
            dirtyRect()?.let { clearBuffer(it) }
        }
        saved = null
        active = false
    }

    fun undo(): Boolean {
        if (active) return false
        val entry = history.popUndo() ?: return false
        when (entry) {
            is StrokePatch -> findLayer(entry.layerId)?.let { l ->
                entry.tiles.forEach { l.canvas.drawBitmap(it.before, it.x.toFloat(), it.y.toFloat(), copyPaint) }
            }
            is LayerAddEntry -> {
                layerList.removeAt(entry.index)
                setActive(entry.activeBefore)
            }
            is LayerRemoveEntry -> {
                layerList.add(entry.index, entry.layer)
                setActive(entry.activeBefore)
            }
            is LayerMoveEntry -> {
                moveRaw(entry.to, entry.from)
                setActive(entry.activeBefore)
            }
            is LayerPropsEntry -> findLayer(entry.layerId)?.assign(entry.before)
            is LayerMergeEntry -> {
                findLayer(entry.lowerId)?.canvas?.drawBitmap(entry.lowerBefore, 0f, 0f, copyPaint)
                layerList.add(entry.removedIndex, entry.removed)
                setActive(entry.activeBefore)
            }
        }
        changed()
        return true
    }

    fun redo(): Boolean {
        if (active) return false
        val entry = history.popRedo() ?: return false
        when (entry) {
            is StrokePatch -> findLayer(entry.layerId)?.let { l ->
                entry.tiles.forEach { l.canvas.drawBitmap(it.after, it.x.toFloat(), it.y.toFloat(), copyPaint) }
            }
            is LayerAddEntry -> {
                layerList.add(entry.index, entry.layer)
                setActive(entry.activeAfter)
            }
            is LayerRemoveEntry -> {
                layerList.removeAt(entry.index)
                setActive(entry.activeAfter)
            }
            is LayerMoveEntry -> {
                moveRaw(entry.from, entry.to)
                setActive(entry.activeAfter)
            }
            is LayerPropsEntry -> findLayer(entry.layerId)?.assign(entry.after)
            is LayerMergeEntry -> {
                val lower = findLayer(entry.lowerId)
                if (lower != null) drawOnto(lower, entry.removed)
                layerList.remove(entry.removed)
                setActive(entry.activeAfter)
            }
        }
        changed()
        return true
    }

    fun selectLayer(index: Int) {
        if (active || index !in layerList.indices || index == activeIndex) return
        activeIndex = index
        onSelection?.invoke()
    }

    fun addLayer(): Boolean {
        if (active) return false
        if (layerList.size >= maxLayers) {
            onNotice?.invoke("Límite de capas alcanzado para este tamaño de lienzo ($maxLayers).")
            return false
        }
        val layer = try {
            Layer.blank(Layer.newId(), LayerRules.nextName(layerList.map { it.name }), width, height)
        } catch (e: OutOfMemoryError) {
            onNotice?.invoke("Memoria insuficiente para crear otra capa.")
            return false
        }
        val index = activeIndex + 1
        val before = activeIndex
        layerList.add(index, layer)
        activeIndex = index
        history.push(LayerAddEntry(layer, index, before, index))
        changed()
        return true
    }

    fun duplicateLayer(): Boolean {
        if (active) return false
        if (layerList.size >= maxLayers) {
            onNotice?.invoke("Límite de capas alcanzado para este tamaño de lienzo ($maxLayers).")
            return false
        }
        val src = layerList[activeIndex]
        val copy = try {
            src.copy(Layer.newId(), LayerRules.cleanName(src.name + " copia"))
        } catch (e: OutOfMemoryError) {
            onNotice?.invoke("Memoria insuficiente para duplicar la capa.")
            return false
        }
        val index = activeIndex + 1
        val before = activeIndex
        layerList.add(index, copy)
        activeIndex = index
        history.push(LayerAddEntry(copy, index, before, index))
        changed()
        return true
    }

    fun removeLayer(): Boolean {
        if (active) return false
        if (layerList.size <= 1) {
            onNotice?.invoke("El dibujo necesita al menos una capa.")
            return false
        }
        val layer = layerList[activeIndex]
        if (layer.locked) {
            onNotice?.invoke("Desbloquea la capa antes de eliminarla.")
            return false
        }
        val index = activeIndex
        val newActive = (index - 1).coerceAtLeast(0)
        layerList.removeAt(index)
        activeIndex = newActive
        history.push(LayerRemoveEntry(layer, index, index, newActive))
        changed()
        return true
    }

    fun moveActive(delta: Int): Boolean {
        if (active) return false
        val from = activeIndex
        val to = from + delta
        if (to !in layerList.indices) return false
        moveRaw(from, to)
        activeIndex = to
        history.push(LayerMoveEntry(from, to, from, to))
        changed()
        return true
    }

    fun mergeDown(): Boolean {
        if (active) return false
        val upperIndex = activeIndex
        if (upperIndex == 0) {
            onNotice?.invoke("No hay una capa inferior con la que combinar.")
            return false
        }
        val upper = layerList[upperIndex]
        val lower = layerList[upperIndex - 1]
        if (upper.locked || lower.locked) {
            onNotice?.invoke("Desbloquea las capas antes de combinarlas.")
            return false
        }
        if (!upper.visible || !lower.visible) {
            onNotice?.invoke("Ambas capas deben estar visibles para combinarlas.")
            return false
        }
        val backup = try {
            lower.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } catch (e: OutOfMemoryError) {
            onNotice?.invoke("Memoria insuficiente para combinar las capas.")
            return false
        }
        drawOnto(lower, upper)
        layerList.removeAt(upperIndex)
        activeIndex = upperIndex - 1
        history.push(LayerMergeEntry(upper, upperIndex, lower.id, backup, upperIndex, activeIndex))
        changed()
        return true
    }

    fun setVisible(index: Int, value: Boolean) = changeProps(index) { it.copy(visible = value) }

    fun setLocked(index: Int, value: Boolean) = changeProps(index) { it.copy(locked = value) }

    fun rename(index: Int, newName: String) {
        val clean = LayerRules.cleanName(newName)
        if (clean.isEmpty()) {
            onNotice?.invoke("El nombre no puede estar vacío.")
            return
        }
        changeProps(index) { it.copy(name = clean) }
    }

    fun previewOpacity(index: Int, value: Float) {
        if (active || index !in layerList.indices) return
        val layer = layerList[index]
        if (pendingOpacity == null) pendingOpacity = layer.id to layer.props()
        layer.opacity = value.coerceIn(0f, 1f)
        redraw?.invoke()
    }

    fun commitOpacity() {
        val pending = pendingOpacity ?: return
        pendingOpacity = null
        val layer = findLayer(pending.first) ?: return
        val after = layer.props()
        if (after != pending.second) {
            history.push(LayerPropsEntry(layer.id, pending.second, after))
            changed()
        }
    }

    fun flatten(): Bitmap = Compositor.flatten(layerList, width, height)

    fun snapshotLayers(): List<Layer> {
        val out = ArrayList<Layer>(layerList.size)
        try {
            for (l in layerList) out.add(l.copy(l.id, l.name))
        } catch (e: OutOfMemoryError) {
            out.forEach { it.bitmap.recycle() }
            throw e
        }
        return out
    }

    fun release() {
        if (!active) {
            strokeBuf?.recycle()
            strokeBuf = null
            strokeCanvas = null
        }
        redraw = null
        onChange = null
        onSelection = null
        onNotice = null
    }

    private fun changeProps(index: Int, block: (LayerProps) -> LayerProps) {
        if (active || index !in layerList.indices) return
        val layer = layerList[index]
        val before = layer.props()
        val after = block(before)
        if (after == before) return
        layer.assign(after)
        history.push(LayerPropsEntry(layer.id, before, after))
        changed()
    }

    private fun drawOnto(lower: Layer, upper: Layer) {
        compositePaint.alpha = (upper.opacity * 255f).roundToInt().coerceIn(0, 255)
        lower.canvas.drawBitmap(upper.bitmap, 0f, 0f, compositePaint)
    }

    private fun moveRaw(from: Int, to: Int) {
        val l = layerList.removeAt(from)
        layerList.add(to, l)
    }

    private fun setActive(i: Int) {
        activeIndex = i.coerceIn(0, layerList.size - 1)
    }

    private fun findLayer(id: String): Layer? = layerList.firstOrNull { it.id == id }

    private fun changed() {
        onChange?.invoke()
        onSelection?.invoke()
        redraw?.invoke()
    }

    private fun ensureBuffer() {
        if (strokeBuf != null || bufferFailed) return
        try {
            val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            strokeBuf = b
            strokeCanvas = Canvas(b)
        } catch (e: OutOfMemoryError) {
            bufferFailed = true
        }
    }

    private fun addPoint(x: Float, y: Float, p: Float) {
        val w = cur.widthFor(curSize, p)
        val mx = (lastX + x) / 2f
        val my = (lastY + y) / 2f
        val mw = (lastW + w) / 2f
        curve(midX, midY, lastX, lastY, mx, my, midW, mw)
        lastX = x; lastY = y; lastW = w
        midX = mx; midY = my; midW = mw
    }

    private fun curve(x0: Float, y0: Float, cx: Float, cy: Float, x1: Float, y1: Float, w0: Float, w1: Float) {
        val len = hypot(cx - x0, cy - y0) + hypot(x1 - cx, y1 - cy)
        val step = max(1f, min(w0, w1) * cur.spacing)
        val n = ceil(len / step).toInt().coerceIn(1, 256)
        var px = x0
        var py = y0
        var pw = w0
        for (i in 1..n) {
            val t = i.toFloat() / n
            val u = 1f - t
            val x = u * u * x0 + 2f * u * t * cx + t * t * x1
            val y = u * u * y0 + 2f * u * t * cy + t * t * y1
            val w = w0 + (w1 - w0) * t
            if (cur.soft) stamp(x, y, w) else segment(px, py, x, y, pw, w)
            px = x; py = y; pw = w
        }
    }

    private fun stamp(x: Float, y: Float, w: Float) {
        val r = w / 2f + 2f
        touch(x - r, y - r, x + r, y + r)
        if (cur.soft) {
            target.save()
            target.translate(x, y)
            target.scale(w / 2f, w / 2f)
            target.drawCircle(0f, 0f, 1f, softPaint)
            target.restore()
        } else {
            paint.strokeWidth = w
            target.drawPoint(x, y, paint)
        }
    }

    private fun segment(px: Float, py: Float, x: Float, y: Float, pw: Float, w: Float) {
        val r = max(pw, w) / 2f + 2f
        touch(min(px, x) - r, min(py, y) - r, max(px, x) + r, max(py, y) + r)
        paint.strokeWidth = (pw + w) / 2f
        target.drawLine(px, py, x, y, paint)
    }

    private fun touch(l: Float, t: Float, r: Float, b: Float) {
        dl = min(dl, l); dt = min(dt, t); dr = max(dr, r); db = max(db, b)
        if (direct) saveTiles(l, t, r, b)
    }

    private fun dirtyRect(): Rect? {
        val l = floor(dl).toInt().coerceAtLeast(0)
        val t = floor(dt).toInt().coerceAtLeast(0)
        val r = ceil(dr).toInt().coerceAtMost(width)
        val b = ceil(db).toInt().coerceAtMost(height)
        return if (l < r && t < b) Rect(l, t, r, b) else null
    }

    private fun clearBuffer(rect: Rect) {
        strokeCanvas?.let {
            it.save()
            it.clipRect(rect)
            it.drawColor(0, PorterDuff.Mode.CLEAR)
            it.restore()
        }
    }

    private fun saveTiles(l: Float, t: Float, r: Float, b: Float) {
        val store = saved ?: return
        val x0 = floor(l).toInt().coerceAtLeast(0)
        val y0 = floor(t).toInt().coerceAtLeast(0)
        val x1 = ceil(r).toInt().coerceAtMost(width - 1)
        val y1 = ceil(b).toInt().coerceAtMost(height - 1)
        if (x0 > x1 || y0 > y1) return
        val src = strokeLayer.bitmap
        for (ty in (y0 / TILE)..(y1 / TILE)) {
            for (tx in (x0 / TILE)..(x1 / TILE)) {
                val key = ty.toLong() * cols + tx
                if (store.containsKey(key)) continue
                val px = tx * TILE
                val py = ty * TILE
                store[key] = Bitmap.createBitmap(src, px, py, min(TILE, width - px), min(TILE, height - py))
            }
        }
    }

    companion object {
        const val TILE = 256
    }
}
