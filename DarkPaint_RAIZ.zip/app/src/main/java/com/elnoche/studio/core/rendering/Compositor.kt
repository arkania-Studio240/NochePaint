package com.elnoche.studio.core.rendering

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import com.elnoche.studio.core.model.Layer
import kotlin.math.roundToInt

object Compositor {

    fun flatten(layers: List<Layer>, width: Int, height: Int): Bitmap {
        val out = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val paint = Paint()
        for (layer in layers) {
            if (!layer.visible) continue
            paint.alpha = (layer.opacity * 255f).roundToInt().coerceIn(0, 255)
            canvas.drawBitmap(layer.bitmap, 0f, 0f, paint)
        }
        return out
    }
}
