package com.elnoche.studio

import com.elnoche.studio.core.drawing.StrokeFilter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StrokeFilterTest {
    @Test
    fun withoutFiltersPointsPassThrough() {
        val f = StrokeFilter()
        f.start(0f, 0f, 1f)
        assertTrue(f.add(10f, 20f, 0.5f, 1f))
        assertEquals(10f, f.outX, 1e-4f)
        assertEquals(20f, f.outY, 1e-4f)
        assertEquals(0.5f, f.outP, 1e-4f)
    }

    @Test
    fun stabilizerIgnoresMovesInsideTheRope() {
        val f = StrokeFilter().apply { stabilization = 1f }
        f.start(0f, 0f, 1f)
        assertFalse(f.add(30f, 0f, 1f, 1f))
        assertTrue(f.add(100f, 0f, 1f, 1f))
        assertEquals(20f, f.outX, 1e-3f)
    }

    @Test
    fun smoothingLagsBehindInput() {
        val f = StrokeFilter().apply { smoothing = 1f }
        f.start(0f, 0f, 1f)
        f.add(100f, 0f, 1f, 1f)
        assertEquals(15f, f.outX, 1e-3f)
    }

    @Test
    fun flushReachesLastRawPoint() {
        val f = StrokeFilter().apply { smoothing = 1f; stabilization = 1f }
        f.start(0f, 0f, 1f)
        f.add(300f, 40f, 0.7f, 1f)
        f.flush()
        assertEquals(300f, f.outX, 1e-4f)
        assertEquals(40f, f.outY, 1e-4f)
    }
}
