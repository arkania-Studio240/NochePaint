package com.elnoche.studio

import com.elnoche.studio.core.drawing.BrushType
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class BrushTypeTest {
    @Test
    fun pressureScalesWidthForInk() {
        assertEquals(15f, BrushType.INK.widthFor(100f, 0f), 1e-3f)
        assertEquals(100f, BrushType.INK.widthFor(100f, 1f), 1e-3f)
    }

    @Test
    fun markerIgnoresPressure() {
        assertEquals(30f, BrushType.MARKER.widthFor(30f, 0.1f), 1e-3f)
    }

    @Test
    fun widthNeverDropsBelowOnePixel() {
        assertEquals(1f, BrushType.INK.widthFor(1f, 0f), 0f)
    }

    @Test
    fun onlyEraserErases() {
        assertTrue(BrushType.ERASER.erases)
        assertTrue(BrushType.entries.filter { it.erases }.size == 1)
    }
}
