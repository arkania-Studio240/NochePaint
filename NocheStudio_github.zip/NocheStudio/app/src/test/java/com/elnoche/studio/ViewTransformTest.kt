package com.elnoche.studio

import com.elnoche.studio.core.model.ViewTransform
import org.junit.Assert.assertEquals
import org.junit.Test

class ViewTransformTest {
    @Test
    fun screenAndDocumentCoordinatesRoundTrip() {
        val t = ViewTransform().apply { scale = 2f; tx = 30f; ty = -10f }
        assertEquals(100f, t.toScreenX(t.toDocX(100f)), 1e-3f)
        assertEquals(55f, t.toScreenY(t.toDocY(55f)), 1e-3f)
    }

    @Test
    fun zoomKeepsFocalPointFixed() {
        val t = ViewTransform().apply { tx = 15f; ty = 5f }
        val before = t.toDocX(200f)
        t.zoomAt(2.5f, 200f, 120f)
        assertEquals(before, t.toDocX(200f), 1e-3f)
    }

    @Test
    fun zoomIsClamped() {
        val t = ViewTransform()
        t.zoomAt(10_000f, 0f, 0f)
        assertEquals(ViewTransform.MAX_SCALE, t.scale, 0f)
        t.zoomAt(0.0000001f, 0f, 0f)
        assertEquals(ViewTransform.MIN_SCALE, t.scale, 0f)
    }

    @Test
    fun fitCentersDocument() {
        val t = ViewTransform()
        t.fit(1000f, 500f, 100f, 100f, margin = 1f)
        assertEquals(5f, t.scale, 1e-3f)
        assertEquals(250f, t.tx, 1e-3f)
        assertEquals(0f, t.ty, 1e-3f)
    }
}
