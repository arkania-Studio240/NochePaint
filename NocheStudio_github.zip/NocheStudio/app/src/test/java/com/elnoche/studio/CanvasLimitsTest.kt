package com.elnoche.studio

import com.elnoche.studio.core.model.CanvasLimits
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Test

class CanvasLimitsTest {
    @Test
    fun acceptsValidSizes() {
        assertNull(CanvasLimits.validate(2048, 2048))
        assertNull(CanvasLimits.validate(64, 4096))
    }

    @Test
    fun rejectsOutOfRangeSizes() {
        assertNotNull(CanvasLimits.validate(63, 500))
        assertNotNull(CanvasLimits.validate(5000, 500))
        assertNotNull(CanvasLimits.validate(4096, 4097))
    }
}
