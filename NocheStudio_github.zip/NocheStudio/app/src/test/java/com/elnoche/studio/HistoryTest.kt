package com.elnoche.studio

import com.elnoche.studio.core.history.History
import com.elnoche.studio.core.history.HistoryEntry
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertSame
import org.junit.Assert.assertTrue
import org.junit.Test

class HistoryTest {
    private class E(override val sizeBytes: Long = 10) : HistoryEntry

    @Test
    fun undoThenRedoReturnsSameEntry() {
        val h = History()
        val e = E()
        h.push(e)
        assertSame(e, h.popUndo())
        assertTrue(h.canRedo)
        assertSame(e, h.popRedo())
        assertFalse(h.canRedo)
    }

    @Test
    fun pushClearsRedo() {
        val h = History()
        h.push(E()); h.push(E())
        h.popUndo()
        h.push(E())
        assertFalse(h.canRedo)
        assertEquals(2, h.undoCount)
    }

    @Test
    fun oldestEntriesAreDroppedWhenOverLimit() {
        val h = History(maxBytes = 25, maxSteps = 100)
        repeat(5) { h.push(E(10)) }
        assertEquals(2, h.undoCount)
    }

    @Test
    fun emptyHistoryReturnsNull() {
        assertNull(History().popUndo())
        assertNull(History().popRedo())
    }
}
