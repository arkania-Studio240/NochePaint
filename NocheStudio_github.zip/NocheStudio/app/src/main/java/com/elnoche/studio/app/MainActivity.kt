package com.elnoche.studio.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import com.elnoche.studio.app.navigation.Screen
import com.elnoche.studio.ui.editor.EditorScreen
import com.elnoche.studio.ui.editor.EditorViewModel
import com.elnoche.studio.ui.gallery.GalleryScreen
import com.elnoche.studio.ui.theme.NocheTheme

class MainActivity : ComponentActivity() {

    private val vm: EditorViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            NocheTheme {
                val snackbar = remember { SnackbarHostState() }
                LaunchedEffect(vm.message) {
                    vm.message?.let {
                        vm.consumeMessage()
                        snackbar.showSnackbar(it)
                    }
                }
                Scaffold(
                    snackbarHost = { SnackbarHost(snackbar) },
                    containerColor = MaterialTheme.colorScheme.background
                ) { padding ->
                    Box(Modifier.padding(padding).fillMaxSize()) {
                        when (vm.screen) {
                            Screen.GALLERY -> GalleryScreen(vm)
                            Screen.EDITOR -> EditorScreen(vm)
                        }
                    }
                }
            }
        }
    }

    override fun onStop() {
        super.onStop()
        if (vm.engine != null && vm.dirty) vm.save()
    }
}
