package com.elnoche.studio.feature.export

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import com.elnoche.studio.core.model.CanvasLimits

class ImportException(message: String) : Exception(message)

object ImageImporter {

    fun decode(resolver: ContentResolver, uri: Uri): Bitmap {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        val first = resolver.openInputStream(uri) ?: throw ImportException("No se pudo leer el archivo")
        first.use { BitmapFactory.decodeStream(it, null, bounds) }
        val w = bounds.outWidth
        val h = bounds.outHeight
        if (w <= 0 || h <= 0) throw ImportException("El archivo no es una imagen compatible")

        var sample = 1
        while (w / sample > CanvasLimits.MAX_SIDE || h / sample > CanvasLimits.MAX_SIDE ||
            (w / sample).toLong() * (h / sample) > CanvasLimits.MAX_PIXELS
        ) sample *= 2
        if (w / sample < CanvasLimits.MIN_SIDE || h / sample < CanvasLimits.MIN_SIDE) {
            throw ImportException("La imagen es demasiado pequeña o tiene proporciones extremas")
        }

        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inMutable = true
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val second = resolver.openInputStream(uri) ?: throw ImportException("No se pudo leer el archivo")
        val bmp = second.use { BitmapFactory.decodeStream(it, null, opts) }
            ?: throw ImportException("La imagen está dañada")
        CanvasLimits.validate(bmp.width, bmp.height)?.let { throw ImportException(it) }
        return bmp
    }
}
