package com.elnoche.studio.core.model

import android.graphics.Bitmap

object CanvasLimits {
    const val MIN_SIDE = 64
    const val MAX_SIDE = 4096
    const val MAX_PIXELS = 16_777_216L

    fun validate(width: Int, height: Int): String? = when {
        width < MIN_SIDE || height < MIN_SIDE -> "El mínimo es $MIN_SIDE px por lado."
        width > MAX_SIDE || height > MAX_SIDE -> "El máximo es $MAX_SIDE px por lado."
        width.toLong() * height > MAX_PIXELS -> "El máximo total es 16 megapíxeles."
        else -> null
    }
}

data class ProjectSummary(
    val id: String,
    val name: String,
    val width: Int,
    val height: Int,
    val modified: Long,
    val thumb: Bitmap?,
    val valid: Boolean
)
