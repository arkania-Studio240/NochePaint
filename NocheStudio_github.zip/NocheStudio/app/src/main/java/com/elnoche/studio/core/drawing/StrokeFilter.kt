package com.elnoche.studio.core.drawing

import kotlin.math.hypot
import kotlin.math.max

class StrokeFilter {
    var smoothing = 0f
    var stabilization = 0f

    var outX = 0f; private set
    var outY = 0f; private set
    var outP = 1f; private set

    private var tipX = 0f
    private var tipY = 0f
    private var emaX = 0f
    private var emaY = 0f
    private var emaP = 1f
    private var rawX = 0f
    private var rawY = 0f
    private var rawP = 1f

    fun start(x: Float, y: Float, p: Float) {
        tipX = x; tipY = y
        emaX = x; emaY = y; emaP = p
        rawX = x; rawY = y; rawP = p
        outX = x; outY = y; outP = p
    }

    fun add(x: Float, y: Float, p: Float, scale: Float): Boolean {
        rawX = x; rawY = y; rawP = p
        var px = x
        var py = y
        if (stabilization > 0f) {
            val rope = stabilization * ROPE_SCREEN_PX / scale
            val dx = x - tipX
            val dy = y - tipY
            val d = hypot(dx, dy)
            if (d <= rope) return false
            val k = (d - rope) / d
            tipX += dx * k
            tipY += dy * k
            px = tipX
            py = tipY
        } else {
            tipX = x
            tipY = y
        }
        val a = 1f - smoothing * 0.85f
        emaX += (px - emaX) * a
        emaY += (py - emaY) * a
        emaP += (p - emaP) * max(a, 0.3f)
        outX = emaX; outY = emaY; outP = emaP
        return true
    }

    fun flush() {
        outX = rawX; outY = rawY; outP = rawP
    }

    companion object {
        const val ROPE_SCREEN_PX = 80f
    }
}
