package com.elnoche.studio.core.storage

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import com.elnoche.studio.core.model.CanvasLimits
import com.elnoche.studio.core.model.ProjectSummary
import org.json.JSONArray
import org.json.JSONException
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.file.AtomicMoveNotSupportedException
import java.nio.file.Files
import java.nio.file.StandardCopyOption
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipFile
import java.util.zip.ZipOutputStream

class ProjectFormatException(message: String) : Exception(message)

data class Manifest(
    val formatVersion: Int,
    val name: String,
    val width: Int,
    val height: Int,
    val background: Int,
    val created: Long,
    val modified: Long,
    val layerFile: String
)

class LoadedProject(val manifest: Manifest, val bitmap: Bitmap)

class ProjectStorage(context: Context) {

    private val dir = File(context.filesDir, "projects").apply { mkdirs() }

    fun newId(): String = UUID.randomUUID().toString()

    fun fileFor(id: String) = File(dir, "$id.noche")

    fun save(id: String, name: String, width: Int, height: Int, background: Int, created: Long, layer: Bitmap) {
        val tmp = File(dir, "$id.noche.tmp")
        try {
            ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zip ->
                zip.putNextEntry(ZipEntry(MANIFEST))
                zip.write(buildManifest(name, width, height, background, created).toString().toByteArray(Charsets.UTF_8))
                zip.closeEntry()
                zip.putNextEntry(ZipEntry(LAYER_0))
                layer.compress(Bitmap.CompressFormat.PNG, 100, zip)
                zip.closeEntry()
                zip.putNextEntry(ZipEntry(THUMB))
                makeThumb(layer, background).also {
                    it.compress(Bitmap.CompressFormat.PNG, 100, zip)
                    it.recycle()
                }
                zip.closeEntry()
            }
            ZipFile(tmp).use { zf ->
                readManifest(zf)
                val layerEntry = zf.getEntry(LAYER_0)
                if (layerEntry == null || layerEntry.size <= 0) throw ProjectFormatException("Guardado incompleto")
            }
            commit(tmp, fileFor(id))
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }

    fun copyWithName(srcId: String, dstId: String, newName: String) {
        val tmp = File(dir, "$dstId.noche.tmp")
        try {
            ZipFile(fileFor(srcId)).use { zf ->
                readManifest(zf)
                val entry = zf.getEntry(MANIFEST)!!
                val json = JSONObject(zf.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) })
                val now = System.currentTimeMillis()
                json.put("name", newName)
                json.put("modified", now)
                if (srcId != dstId) json.put("created", now)
                ZipOutputStream(BufferedOutputStream(FileOutputStream(tmp))).use { zip ->
                    zip.putNextEntry(ZipEntry(MANIFEST))
                    zip.write(json.toString().toByteArray(Charsets.UTF_8))
                    zip.closeEntry()
                    for (e in zf.entries()) {
                        if (e.name == MANIFEST || e.isDirectory) continue
                        zip.putNextEntry(ZipEntry(e.name))
                        zf.getInputStream(e).use { it.copyTo(zip) }
                        zip.closeEntry()
                    }
                }
            }
            ZipFile(tmp).use { readManifest(it) }
            commit(tmp, fileFor(dstId))
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    }

    private fun commit(tmp: File, target: File) {
        try {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE)
        } catch (e: AtomicMoveNotSupportedException) {
            Files.move(tmp.toPath(), target.toPath(), StandardCopyOption.REPLACE_EXISTING)
        }
    }

    fun load(file: File): LoadedProject {
        try {
            ZipFile(file).use { zf ->
                val manifest = readManifest(zf)
                val entry = zf.getEntry(manifest.layerFile)
                    ?: throw ProjectFormatException("Falta el contenido de la capa")
                val opts = BitmapFactory.Options().apply {
                    inMutable = true
                    inPreferredConfig = Bitmap.Config.ARGB_8888
                }
                val bmp = zf.getInputStream(entry).use { BitmapFactory.decodeStream(it, null, opts) }
                    ?: throw ProjectFormatException("La imagen de la capa está dañada")
                if (bmp.width != manifest.width || bmp.height != manifest.height) {
                    throw ProjectFormatException("Las dimensiones no coinciden")
                }
                return LoadedProject(manifest, bmp)
            }
        } catch (e: java.util.zip.ZipException) {
            throw ProjectFormatException("El archivo no es un proyecto válido")
        }
    }

    fun list(): List<ProjectSummary> {
        val files = dir.listFiles { f -> f.isFile && f.name.endsWith(".noche") } ?: return emptyList()
        return files.map { f ->
            val id = f.name.removeSuffix(".noche")
            try {
                ZipFile(f).use { zf ->
                    val m = readManifest(zf)
                    val thumb = zf.getEntry(THUMB)?.let { e ->
                        zf.getInputStream(e).use { BitmapFactory.decodeStream(it) }
                    }
                    ProjectSummary(id, m.name, m.width, m.height, m.modified, thumb, true)
                }
            } catch (e: Exception) {
                ProjectSummary(id, "Archivo no válido", 0, 0, f.lastModified(), null, false)
            }
        }.sortedByDescending { it.modified }
    }

    fun delete(id: String) {
        fileFor(id).delete()
    }

    private fun buildManifest(name: String, width: Int, height: Int, background: Int, created: Long): JSONObject =
        JSONObject().apply {
            put("formatVersion", FORMAT_VERSION)
            put("app", "NocheStudio")
            put("name", name)
            put("width", width)
            put("height", height)
            put("background", background)
            put("created", created)
            put("modified", System.currentTimeMillis())
            put("layers", JSONArray().put(JSONObject().apply {
                put("id", "layer-1")
                put("name", "Capa 1")
                put("visible", true)
                put("opacity", 1.0)
                put("file", LAYER_0)
            }))
        }

    private fun readManifest(zf: ZipFile): Manifest {
        val entry = zf.getEntry(MANIFEST) ?: throw ProjectFormatException("Falta el manifiesto")
        if (entry.size <= 0 || entry.size > 1_000_000) throw ProjectFormatException("Manifiesto inválido")
        val text = zf.getInputStream(entry).use { it.readBytes().toString(Charsets.UTF_8) }
        try {
            val o = JSONObject(text)
            val version = o.getInt("formatVersion")
            if (version < 1) throw ProjectFormatException("Versión de formato inválida")
            if (version > FORMAT_VERSION) throw ProjectFormatException("Creado con una versión más nueva de la app")
            val w = o.getInt("width")
            val h = o.getInt("height")
            CanvasLimits.validate(w, h)?.let { throw ProjectFormatException(it) }
            val layers = o.getJSONArray("layers")
            if (layers.length() < 1) throw ProjectFormatException("El proyecto no tiene capas")
            return Manifest(
                version, o.optString("name", "Sin nombre"), w, h,
                o.optInt("background", -1), o.optLong("created", 0L), o.optLong("modified", 0L),
                layers.getJSONObject(0).getString("file")
            )
        } catch (e: JSONException) {
            throw ProjectFormatException("Manifiesto ilegible")
        }
    }

    private fun makeThumb(src: Bitmap, background: Int): Bitmap {
        val ratio = THUMB_MAX.toFloat() / maxOf(src.width, src.height)
        val tw = maxOf(1, (src.width * ratio).toInt())
        val th = maxOf(1, (src.height * ratio).toInt())
        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        c.drawColor(if ((background ushr 24) == 0) 0xFFDDDDDD.toInt() else background)
        c.drawBitmap(src, null, Rect(0, 0, tw, th), Paint(Paint.FILTER_BITMAP_FLAG))
        return out
    }

    companion object {
        const val FORMAT_VERSION = 1
        private const val MANIFEST = "manifest.json"
        private const val LAYER_0 = "layers/layer0.png"
        private const val THUMB = "thumb.png"
        private const val THUMB_MAX = 256
    }
}
