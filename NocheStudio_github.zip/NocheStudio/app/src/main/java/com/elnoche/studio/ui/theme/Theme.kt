package com.elnoche.studio.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val NocheColors = darkColorScheme(
    primary = Color(0xFF8FA8FF),
    onPrimary = Color(0xFF0B0B0F),
    background = Color(0xFF141416),
    onBackground = Color(0xFFE6E6EA),
    surface = Color(0xFF1C1C20),
    onSurface = Color(0xFFE6E6EA),
    surfaceVariant = Color(0xFF26262B),
    onSurfaceVariant = Color(0xFFA9A9B3),
    secondaryContainer = Color(0xFF30344D),
    onSecondaryContainer = Color(0xFFE6E6EA),
    outline = Color(0xFF5A5A64)
)

@Composable
fun NocheTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = NocheColors, content = content)
}
