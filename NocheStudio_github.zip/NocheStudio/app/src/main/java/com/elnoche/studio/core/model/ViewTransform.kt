package com.elnoche.studio.core.model

import kotlin.math.min

class ViewTransform {
    var scale = 1f
    var tx = 0f
    var ty = 0f

    fun toDocX(sx: Float) = (sx - tx) / scale
    fun toDocY(sy: Float) = (sy - ty) / scale
    fun toScreenX(dx: Float) = dx * scale + tx
    fun toScreenY(dy: Float) = dy * scale + ty

    fun zoomAt(factor: Float, fx: Float, fy: Float) {
        val newScale = (scale * factor).coerceIn(MIN_SCALE, MAX_SCALE)
        val f = newScale / scale
        tx = fx - (fx - tx) * f
        ty = fy - (fy - ty) * f
        scale = newScale
    }

    fun pan(dx: Float, dy: Float) {
        tx += dx
        ty += dy
    }

    fun fit(viewW: Float, viewH: Float, docW: Float, docH: Float, margin: Float = 0.95f) {
        scale = (min(viewW / docW, viewH / docH) * margin).coerceIn(MIN_SCALE, MAX_SCALE)
        tx = (viewW - docW * scale) / 2f
        ty = (viewH - docH * scale) / 2f
    }

    companion object {
        const val MIN_SCALE = 0.05f
        const val MAX_SCALE = 32f
    }
}
