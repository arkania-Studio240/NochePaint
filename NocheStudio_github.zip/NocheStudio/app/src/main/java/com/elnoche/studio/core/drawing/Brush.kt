package com.elnoche.studio.core.drawing

enum class BrushType(
    val label: String,
    val pressureSize: Boolean,
    val minPressure: Float,
    val opacityScale: Float,
    val soft: Boolean = false,
    val square: Boolean = false,
    val erases: Boolean = false
) {
    PENCIL("Lápiz", true, 0.5f, 0.85f),
    BRUSH("Pincel", true, 0.3f, 1f),
    INK("Pluma", true, 0.15f, 1f),
    AIRBRUSH("Aerógrafo", true, 0.6f, 1f, soft = true),
    MARKER("Marcador", false, 1f, 0.8f, square = true),
    ERASER("Borrador", false, 1f, 1f, erases = true);

    val spacing: Float get() = if (soft) 0.1f else 0.25f

    fun widthFor(size: Float, pressure: Float): Float {
        val w = if (pressureSize) {
            size * (minPressure + (1f - minPressure) * pressure.coerceIn(0f, 1f))
        } else {
            size
        }
        return w.coerceAtLeast(1f)
    }
}
