package com.elnoche.studio.feature.export

import android.content.ContentResolver
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.Uri
import java.io.IOException

enum class ExportFormat(val mime: String, val ext: String, val compress: Bitmap.CompressFormat, val quality: Int) {
    PNG("image/png", "png", Bitmap.CompressFormat.PNG, 100),
    JPEG("image/jpeg", "jpg", Bitmap.CompressFormat.JPEG, 95)
}

object ImageExporter {

    fun suggestedName(projectName: String, format: ExportFormat): String {
        val clean = projectName.replace(Regex("[\\\\/:*?\"<>|]"), "_").trim().ifEmpty { "dibujo" }
        return "$clean.${format.ext}"
    }

    fun write(resolver: ContentResolver, uri: Uri, snapshot: Bitmap, background: Int, format: ExportFormat) {
        val canvas = Canvas(snapshot)
        if ((background ushr 24) != 0) canvas.drawColor(background, PorterDuff.Mode.DST_OVER)
        if (format == ExportFormat.JPEG) canvas.drawColor(Color.WHITE, PorterDuff.Mode.DST_OVER)
        val out = resolver.openOutputStream(uri, "w") ?: throw IOException("No se pudo abrir el destino")
        out.use {
            if (!snapshot.compress(format.compress, format.quality, it)) throw IOException("Falló la compresión")
        }
    }
}
