package com.elnoche.studio.ui.editor

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Shader
import android.view.MotionEvent
import android.view.View
import com.elnoche.studio.core.drawing.DrawingEngine
import kotlin.math.hypot
import kotlin.math.roundToInt

class DrawingView(context: Context) : View(context) {

    var onZoom: ((Int) -> Unit)? = null

    var engine: DrawingEngine? = null
        set(value) {
            if (field === value) return
            field?.redraw = null
            field = value
            value?.redraw = { postInvalidate() }
            layoutEngine()
            invalidate()
        }

    private enum class Mode { NONE, DRAW, GESTURE }

    private var mode = Mode.NONE
    private var gx = 0f
    private var gy = 0f
    private var gd = 0f

    private val bmpPaint = Paint()
    private val livePaint = Paint()
    private var stylusDown = false
    private val bgPaint = Paint()
    private val checkerPaint = Paint().apply {
        val tile = Bitmap.createBitmap(16, 16, Bitmap.Config.ARGB_8888)
        val c = Canvas(tile)
        c.drawColor(0xFFFFFFFF.toInt())
        val p = Paint().apply { color = 0xFFCCCCCC.toInt() }
        c.drawRect(0f, 0f, 8f, 8f, p)
        c.drawRect(8f, 8f, 16f, 16f, p)
        shader = BitmapShader(tile, Shader.TileMode.REPEAT, Shader.TileMode.REPEAT)
    }

    init {
        setBackgroundColor(0xFF0E0E10.toInt())
    }

    fun fitToScreen() {
        val e = engine ?: return
        if (width == 0 || height == 0) return
        e.transform.fit(width.toFloat(), height.toFloat(), e.width.toFloat(), e.height.toFloat())
        notifyZoom()
        invalidate()
    }

    private fun layoutEngine() {
        val e = engine ?: return
        if (width == 0 || height == 0) return
        if (e.viewW > 0 && e.viewH > 0) {
            e.transform.pan((width - e.viewW) / 2f, (height - e.viewH) / 2f)
        } else {
            e.transform.fit(width.toFloat(), height.toFloat(), e.width.toFloat(), e.height.toFloat())
        }
        e.viewW = width
        e.viewH = height
        notifyZoom()
    }

    private fun notifyZoom() {
        val e = engine ?: return
        onZoom?.invoke((e.transform.scale * 100f).roundToInt())
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        layoutEngine()
    }

    override fun onDetachedFromWindow() {
        engine?.redraw = null
        super.onDetachedFromWindow()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        engine?.redraw = { postInvalidate() }
    }

    override fun onDraw(canvas: Canvas) {
        val e = engine ?: return
        val t = e.transform
        canvas.save()
        canvas.translate(t.tx, t.ty)
        canvas.scale(t.scale, t.scale)
        val w = e.width.toFloat()
        val h = e.height.toFloat()
        if ((e.background ushr 24) != 255) canvas.drawRect(0f, 0f, w, h, checkerPaint)
        bgPaint.color = e.background
        canvas.drawRect(0f, 0f, w, h, bgPaint)
        bmpPaint.isFilterBitmap = t.scale < 1.5f
        canvas.drawBitmap(e.bitmap, 0f, 0f, bmpPaint)
        e.liveBuffer?.let {
            livePaint.alpha = e.liveAlpha
            livePaint.isFilterBitmap = bmpPaint.isFilterBitmap
            canvas.drawBitmap(it, 0f, 0f, livePaint)
        }
        canvas.restore()
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        val e = engine ?: return false
        val t = e.transform
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                mode = Mode.DRAW
                stylusDown = ev.getToolType(0) == MotionEvent.TOOL_TYPE_STYLUS
                e.beginStroke(t.toDocX(ev.x), t.toDocY(ev.y), pressure(ev, -1))
                invalidate()
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                if (mode == Mode.DRAW && stylusDown) return true
                if (mode == Mode.DRAW) e.cancelStroke()
                mode = Mode.GESTURE
                captureGesture(ev, -1)
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> when (mode) {
                Mode.DRAW -> {
                    for (i in 0 until ev.historySize) {
                        e.moveStroke(t.toDocX(ev.getHistoricalX(i)), t.toDocY(ev.getHistoricalY(i)), pressure(ev, i))
                    }
                    e.moveStroke(t.toDocX(ev.x), t.toDocY(ev.y), pressure(ev, -1))
                    invalidate()
                }
                Mode.GESTURE -> applyGesture(ev)
                Mode.NONE -> Unit
            }
            MotionEvent.ACTION_POINTER_UP -> {
                if (mode == Mode.GESTURE) {
                    if (ev.pointerCount - 1 >= 2) captureGesture(ev, ev.actionIndex) else mode = Mode.NONE
                }
            }
            MotionEvent.ACTION_UP -> {
                if (mode == Mode.DRAW) e.endStroke()
                mode = Mode.NONE
                invalidate()
            }
            MotionEvent.ACTION_CANCEL -> {
                if (mode == Mode.DRAW) e.cancelStroke()
                mode = Mode.NONE
                invalidate()
            }
        }
        return true
    }

    private fun pressure(ev: MotionEvent, hist: Int): Float {
        if (!stylusDown) return 1f
        val p = if (hist < 0) ev.getPressure(0) else ev.getHistoricalPressure(0, hist)
        return p.coerceIn(0.02f, 1f)
    }

    private fun gesture(ev: MotionEvent, skip: Int): FloatArray? {
        var i0 = -1
        var i1 = -1
        for (i in 0 until ev.pointerCount) {
            if (i == skip) continue
            if (i0 < 0) i0 = i else { i1 = i; break }
        }
        if (i1 < 0) return null
        val cx = (ev.getX(i0) + ev.getX(i1)) / 2f
        val cy = (ev.getY(i0) + ev.getY(i1)) / 2f
        val d = hypot(ev.getX(i0) - ev.getX(i1), ev.getY(i0) - ev.getY(i1))
        return floatArrayOf(cx, cy, d)
    }

    private fun captureGesture(ev: MotionEvent, skip: Int) {
        val g = gesture(ev, skip) ?: return
        gx = g[0]; gy = g[1]; gd = g[2]
    }

    private fun applyGesture(ev: MotionEvent) {
        val e = engine ?: return
        val g = gesture(ev, -1) ?: return
        if (gd > 0f && g[2] > 0f) e.transform.zoomAt(g[2] / gd, gx, gy)
        e.transform.pan(g[0] - gx, g[1] - gy)
        gx = g[0]; gy = g[1]; gd = g[2]
        notifyZoom()
        invalidate()
    }
}
