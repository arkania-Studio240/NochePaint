package com.elnoche.studio.core.drawing

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.RadialGradient
import android.graphics.Rect
import android.graphics.Shader
import com.elnoche.studio.core.history.History
import com.elnoche.studio.core.history.HistoryEntry
import com.elnoche.studio.core.model.ViewTransform
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

class TilePair(val x: Int, val y: Int, val before: Bitmap, val after: Bitmap)

class StrokePatch(val tiles: List<TilePair>) : HistoryEntry {
    override val sizeBytes: Long = tiles.sumOf { it.before.byteCount.toLong() + it.after.byteCount.toLong() }
}

class DrawingEngine(
    val width: Int,
    val height: Int,
    val background: Int,
    existing: Bitmap? = null
) {
    val bitmap: Bitmap = existing ?: Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val history = History()
    val transform = ViewTransform()

    var viewW = 0
    var viewH = 0
    var type = BrushType.BRUSH
    var color = Color.BLACK
    var size = 12f
    var opacity = 1f
    var smoothing: Float
        get() = filter.smoothing
        set(v) { filter.smoothing = v.coerceIn(0f, 1f) }
    var stabilization: Float
        get() = filter.stabilization
        set(v) { filter.stabilization = v.coerceIn(0f, 1f) }

    var onChange: (() -> Unit)? = null
    var redraw: (() -> Unit)? = null

    val liveBuffer: Bitmap? get() = if (active && !direct) strokeBuf else null
    var liveAlpha = 255
        private set

    private val filter = StrokeFilter()
    private val layerCanvas = Canvas(bitmap)
    private var strokeBuf: Bitmap? = null
    private var strokeCanvas: Canvas? = null
    private var bufferFailed = false

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeJoin = Paint.Join.ROUND
    }
    private val softPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val compositePaint = Paint()
    private val copyPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC) }
    private val clearMode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
    private val cols = (width + TILE - 1) / TILE

    private var saved: HashMap<Long, Bitmap>? = null
    private var active = false
    private var direct = false
    private var target: Canvas = layerCanvas
    private var cur = BrushType.BRUSH
    private var curSize = 12f

    private var lastX = 0f
    private var lastY = 0f
    private var lastW = 0f
    private var midX = 0f
    private var midY = 0f
    private var midW = 0f
    private var dl = 0f
    private var dt = 0f
    private var dr = 0f
    private var db = 0f

    fun beginStroke(x: Float, y: Float, pressure: Float) {
        cur = type
        curSize = size
        liveAlpha = (opacity * cur.opacityScale * 255f).roundToInt().coerceIn(1, 255)
        ensureBuffer()
        direct = cur.erases || strokeBuf == null
        target = if (direct) layerCanvas else strokeCanvas!!
        saved = HashMap()
        active = true
        dl = Float.MAX_VALUE; dt = Float.MAX_VALUE; dr = -Float.MAX_VALUE; db = -Float.MAX_VALUE

        val rgb = color and 0x00FFFFFF
        val paintAlpha = if (direct && !cur.erases) liveAlpha else 255
        paint.color = rgb or (paintAlpha shl 24)
        paint.xfermode = if (cur.erases) clearMode else null
        paint.strokeCap = if (cur.square) Paint.Cap.SQUARE else Paint.Cap.ROUND
        if (cur.soft) {
            val flow = (0.06f * paintAlpha).roundToInt().coerceAtLeast(1)
            val c0 = rgb or (flow shl 24)
            softPaint.shader = RadialGradient(
                0f, 0f, 1f, intArrayOf(c0, c0, rgb), floatArrayOf(0f, 0.25f, 1f), Shader.TileMode.CLAMP
            )
        }

        filter.start(x, y, pressure)
        val w = cur.widthFor(curSize, pressure)
        stamp(x, y, w)
        lastX = x; lastY = y; lastW = w
        midX = x; midY = y; midW = w
    }

    fun moveStroke(x: Float, y: Float, pressure: Float) {
        if (!active) return
        if (filter.add(x, y, pressure, transform.scale)) addPoint(filter.outX, filter.outY, filter.outP)
    }

    fun endStroke() {
        if (!active) return
        filter.flush()
        addPoint(filter.outX, filter.outY, filter.outP)
        curve(midX, midY, lastX, lastY, lastX, lastY, midW, lastW)

        if (!direct) {
            dirtyRect()?.let { rect ->
                saveTiles(rect.left.toFloat(), rect.top.toFloat(), rect.right.toFloat(), rect.bottom.toFloat())
                compositePaint.alpha = liveAlpha
                layerCanvas.drawBitmap(strokeBuf!!, rect, rect, compositePaint)
                clearBuffer(rect)
            }
        }

        val before = saved ?: HashMap()
        val tiles = before.map { (key, bmp) ->
            val px = (key % cols).toInt() * TILE
            val py = (key / cols).toInt() * TILE
            TilePair(px, py, bmp, Bitmap.createBitmap(bitmap, px, py, bmp.width, bmp.height))
        }
        saved = null
        active = false
        if (tiles.isNotEmpty()) {
            history.push(StrokePatch(tiles))
            onChange?.invoke()
        }
    }

    fun cancelStroke() {
        if (!active) return
        if (direct) {
            saved?.forEach { (key, bmp) ->
                val px = (key % cols).toInt() * TILE
                val py = (key / cols).toInt() * TILE
                layerCanvas.drawBitmap(bmp, px.toFloat(), py.toFloat(), copyPaint)
            }
        } else {
            dirtyRect()?.let { clearBuffer(it) }
        }
        saved = null
        active = false
    }

    fun undo(): Boolean {
        val patch = history.popUndo() as? StrokePatch ?: return false
        patch.tiles.forEach { layerCanvas.drawBitmap(it.before, it.x.toFloat(), it.y.toFloat(), copyPaint) }
        onChange?.invoke()
        redraw?.invoke()
        return true
    }

    fun redo(): Boolean {
        val patch = history.popRedo() as? StrokePatch ?: return false
        patch.tiles.forEach { layerCanvas.drawBitmap(it.after, it.x.toFloat(), it.y.toFloat(), copyPaint) }
        onChange?.invoke()
        redraw?.invoke()
        return true
    }

    fun release() {
        if (!active) {
            strokeBuf?.recycle()
            strokeBuf = null
            strokeCanvas = null
        }
        redraw = null
        onChange = null
    }

    private fun ensureBuffer() {
        if (strokeBuf != null || bufferFailed) return
        try {
            val b = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            strokeBuf = b
            strokeCanvas = Canvas(b)
        } catch (e: OutOfMemoryError) {
            bufferFailed = true
        }
    }

    private fun addPoint(x: Float, y: Float, p: Float) {
        val w = cur.widthFor(curSize, p)
        val mx = (lastX + x) / 2f
        val my = (lastY + y) / 2f
        val mw = (lastW + w) / 2f
        curve(midX, midY, lastX, lastY, mx, my, midW, mw)
        lastX = x; lastY = y; lastW = w
        midX = mx; midY = my; midW = mw
    }

    private fun curve(x0: Float, y0: Float, cx: Float, cy: Float, x1: Float, y1: Float, w0: Float, w1: Float) {
        val len = hypot(cx - x0, cy - y0) + hypot(x1 - cx, y1 - cy)
        val step = max(1f, min(w0, w1) * cur.spacing)
        val n = ceil(len / step).toInt().coerceIn(1, 256)
        var px = x0
        var py = y0
        var pw = w0
        for (i in 1..n) {
            val t = i.toFloat() / n
            val u = 1f - t
            val x = u * u * x0 + 2f * u * t * cx + t * t * x1
            val y = u * u * y0 + 2f * u * t * cy + t * t * y1
            val w = w0 + (w1 - w0) * t
            if (cur.soft) stamp(x, y, w) else segment(px, py, x, y, pw, w)
            px = x; py = y; pw = w
        }
    }

    private fun stamp(x: Float, y: Float, w: Float) {
        val r = w / 2f + 2f
        touch(x - r, y - r, x + r, y + r)
        if (cur.soft) {
            target.save()
            target.translate(x, y)
            target.scale(w / 2f, w / 2f)
            target.drawCircle(0f, 0f, 1f, softPaint)
            target.restore()
        } else {
            paint.strokeWidth = w
            target.drawPoint(x, y, paint)
        }
    }

    private fun segment(px: Float, py: Float, x: Float, y: Float, pw: Float, w: Float) {
        val r = max(pw, w) / 2f + 2f
        touch(min(px, x) - r, min(py, y) - r, max(px, x) + r, max(py, y) + r)
        paint.strokeWidth = (pw + w) / 2f
        target.drawLine(px, py, x, y, paint)
    }

    private fun touch(l: Float, t: Float, r: Float, b: Float) {
        dl = min(dl, l); dt = min(dt, t); dr = max(dr, r); db = max(db, b)
        if (direct) saveTiles(l, t, r, b)
    }

    private fun dirtyRect(): Rect? {
        val l = floor(dl).toInt().coerceAtLeast(0)
        val t = floor(dt).toInt().coerceAtLeast(0)
        val r = ceil(dr).toInt().coerceAtMost(width)
        val b = ceil(db).toInt().coerceAtMost(height)
        return if (l < r && t < b) Rect(l, t, r, b) else null
    }

    private fun clearBuffer(rect: Rect) {
        strokeCanvas?.let {
            it.save()
            it.clipRect(rect)
            it.drawColor(0, PorterDuff.Mode.CLEAR)
            it.restore()
        }
    }

    private fun saveTiles(l: Float, t: Float, r: Float, b: Float) {
        val store = saved ?: return
        val x0 = floor(l).toInt().coerceAtLeast(0)
        val y0 = floor(t).toInt().coerceAtLeast(0)
        val x1 = ceil(r).toInt().coerceAtMost(width - 1)
        val y1 = ceil(b).toInt().coerceAtMost(height - 1)
        if (x0 > x1 || y0 > y1) return
        for (ty in (y0 / TILE)..(y1 / TILE)) {
            for (tx in (x0 / TILE)..(x1 / TILE)) {
                val key = ty.toLong() * cols + tx
                if (store.containsKey(key)) continue
                val px = tx * TILE
                val py = ty * TILE
                store[key] = Bitmap.createBitmap(bitmap, px, py, min(TILE, width - px), min(TILE, height - py))
            }
        }
    }

    companion object {
        const val TILE = 256
    }
}
