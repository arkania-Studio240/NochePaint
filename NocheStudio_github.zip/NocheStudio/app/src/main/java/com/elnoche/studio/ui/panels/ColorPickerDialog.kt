package com.elnoche.studio.ui.panels

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val PALETTE = listOf(
    0xFF000000, 0xFFFFFFFF, 0xFF808080, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835,
    0xFF43A047, 0xFF00ACC1, 0xFF1E88E5, 0xFF3949AB, 0xFF8E24AA, 0xFFD81B60
).map { it.toInt() }

private fun hexOf(r: Int, g: Int, b: Int) = String.format("%02X%02X%02X", r, g, b)

private fun argb(r: Int, g: Int, b: Int) = (0xFF shl 24) or (r shl 16) or (g shl 8) or b

@Composable
fun ColorPickerDialog(initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    var r by remember { mutableIntStateOf((initial shr 16) and 255) }
    var g by remember { mutableIntStateOf((initial shr 8) and 255) }
    var b by remember { mutableIntStateOf(initial and 255) }
    var hex by remember { mutableStateOf(hexOf(r, g, b)) }

    fun setRgb(nr: Int, ng: Int, nb: Int) {
        r = nr; g = ng; b = nb
        hex = hexOf(nr, ng, nb)
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Color") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(
                    Modifier.fillMaxWidth().height(40.dp).clip(MaterialTheme.shapes.small)
                        .background(Color(argb(r, g, b)))
                        .border(1.dp, MaterialTheme.colorScheme.outline, MaterialTheme.shapes.small)
                )
                PALETTE.chunked(6).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { c ->
                            Box(
                                Modifier.size(32.dp).clip(CircleShape).background(Color(c))
                                    .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                                    .clickable { setRgb((c shr 16) and 255, (c shr 8) and 255, c and 255) }
                            )
                        }
                    }
                }
                ChannelSlider("R", r) { setRgb(it, g, b) }
                ChannelSlider("G", g) { setRgb(r, it, b) }
                ChannelSlider("B", b) { setRgb(r, g, it) }
                OutlinedTextField(
                    value = hex,
                    onValueChange = { s ->
                        val c = s.removePrefix("#").uppercase().take(6)
                        hex = c
                        if (c.length == 6) c.toIntOrNull(16)?.let { v ->
                            r = (v shr 16) and 255; g = (v shr 8) and 255; b = v and 255
                        }
                    },
                    label = { Text("Hex") },
                    singleLine = true
                )
            }
        },
        confirmButton = { TextButton(onClick = { onPick(argb(r, g, b)) }) { Text("Aceptar") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancelar") } }
    )
}

@Composable
private fun ChannelSlider(label: String, value: Int, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.width(16.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.toInt()) },
            valueRange = 0f..255f,
            modifier = Modifier.weight(1f)
        )
        Text(value.toString(), Modifier.width(32.dp))
    }
}
