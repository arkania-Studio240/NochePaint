package com.elnoche.studio.ui.editor

import android.app.Application
import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.elnoche.studio.app.navigation.Screen
import com.elnoche.studio.core.drawing.DrawingEngine
import com.elnoche.studio.core.drawing.BrushType
import com.elnoche.studio.core.model.CanvasLimits
import com.elnoche.studio.core.model.ProjectSummary
import com.elnoche.studio.core.storage.ProjectFormatException
import com.elnoche.studio.core.storage.ProjectStorage
import com.elnoche.studio.feature.export.ExportFormat
import com.elnoche.studio.feature.export.ImageExporter
import com.elnoche.studio.feature.export.ImageImporter
import com.elnoche.studio.feature.export.ImportException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class EditorViewModel(app: Application) : AndroidViewModel(app) {

    private val storage = ProjectStorage(app)

    var screen by mutableStateOf(Screen.GALLERY); private set
    var projects by mutableStateOf<List<ProjectSummary>>(emptyList()); private set
    var engine by mutableStateOf<DrawingEngine?>(null); private set
    var projectName by mutableStateOf(""); private set
    var brush by mutableStateOf(BrushType.BRUSH); private set
    var opacity by mutableFloatStateOf(1f); private set
    var smoothing by mutableFloatStateOf(0.2f); private set
    var stabilization by mutableFloatStateOf(0f); private set
    var color by mutableIntStateOf(Color.BLACK); private set
    var brushSize by mutableFloatStateOf(12f); private set
    var dirty by mutableStateOf(false); private set
    var saved by mutableStateOf(false); private set
    var canUndo by mutableStateOf(false); private set
    var canRedo by mutableStateOf(false); private set
    var busy by mutableStateOf(false); private set
    var message by mutableStateOf<String?>(null); private set
    var zoomPercent by mutableIntStateOf(100)

    private var lastPaintBrush = BrushType.BRUSH
    private var projectId: String? = null
    private var created = 0L
    private var edits = 0

    fun consumeMessage() {
        message = null
    }

    fun refreshProjects() {
        viewModelScope.launch {
            projects = withContext(Dispatchers.IO) { storage.list() }
        }
    }

    fun createProject(width: Int, height: Int, background: Int) {
        CanvasLimits.validate(width, height)?.let { message = it; return }
        try {
            val name = "Dibujo " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
            attach(DrawingEngine(width, height, background), storage.newId(), name, System.currentTimeMillis(), false)
        } catch (e: OutOfMemoryError) {
            message = "Memoria insuficiente para crear un lienzo de ese tamaño."
        }
    }

    fun openProject(summary: ProjectSummary) {
        if (busy) return
        if (!summary.valid) {
            message = "Este archivo no es un proyecto válido. Se conserva sin cambios."
            return
        }
        busy = true
        viewModelScope.launch {
            try {
                val loaded = withContext(Dispatchers.IO) { storage.load(storage.fileFor(summary.id)) }
                val m = loaded.manifest
                attach(DrawingEngine(m.width, m.height, m.background, loaded.bitmap), summary.id, m.name, m.created, true)
            } catch (e: ProjectFormatException) {
                message = "No se pudo abrir el dibujo: ${e.message}. El archivo original no se modificó."
            } catch (e: OutOfMemoryError) {
                message = "Memoria insuficiente para abrir este dibujo."
            } catch (e: Exception) {
                message = "No se pudo abrir el dibujo. El archivo original no se modificó."
            } finally {
                busy = false
            }
        }
    }

    private fun attach(e: DrawingEngine, id: String, name: String, createdAt: Long, alreadySaved: Boolean) {
        e.type = brush
        e.color = color
        e.size = brushSize
        e.opacity = opacity
        e.smoothing = smoothing
        e.stabilization = stabilization
        e.onChange = {
            edits++
            dirty = true
            canUndo = e.history.canUndo
            canRedo = e.history.canRedo
        }
        engine = e
        projectId = id
        projectName = name
        created = createdAt
        edits = 0
        dirty = false
        saved = alreadySaved
        canUndo = false
        canRedo = false
        zoomPercent = 100
        screen = Screen.EDITOR
    }

    fun selectBrush(b: BrushType) {
        brush = b
        engine?.type = b
        if (!b.erases) lastPaintBrush = b
    }

    fun updateColor(c: Int) {
        color = c
        engine?.color = c
        if (brush.erases) selectBrush(lastPaintBrush)
    }

    fun updateOpacity(v: Float) {
        opacity = v
        engine?.opacity = v
    }

    fun updateSmoothing(v: Float) {
        smoothing = v
        engine?.smoothing = v
    }

    fun updateStabilization(v: Float) {
        stabilization = v
        engine?.stabilization = v
    }

    fun updateBrushSize(s: Float) {
        brushSize = s
        engine?.size = s
    }

    fun undo() {
        engine?.undo()
    }

    fun redo() {
        engine?.redo()
    }

    fun save(closeAfter: Boolean = false) {
        val e = engine ?: return
        val id = projectId ?: return
        if (busy) return
        busy = true
        val snapshot = try {
            e.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        } catch (oom: OutOfMemoryError) {
            null
        }
        if (snapshot == null) {
            busy = false
            message = "Memoria insuficiente para guardar."
            return
        }
        val captured = edits
        val name = projectName
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    storage.save(id, name, e.width, e.height, e.background, created, snapshot)
                }
                saved = true
                dirty = edits != captured
                message = "Guardado"
                if (closeAfter) closeEditor()
            } catch (t: Throwable) {
                message = "No se pudo guardar. La versión anterior sigue intacta."
            } finally {
                snapshot.recycle()
                busy = false
            }
        }
    }

    fun exportImage(uri: Uri, format: ExportFormat) {
        val e = engine ?: return
        if (busy) return
        busy = true
        val snapshot = try {
            e.bitmap.copy(Bitmap.Config.ARGB_8888, true)
        } catch (oom: OutOfMemoryError) {
            null
        }
        if (snapshot == null) {
            busy = false
            message = "Memoria insuficiente para exportar."
            return
        }
        val resolver = getApplication<Application>().contentResolver
        val background = e.background
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { ImageExporter.write(resolver, uri, snapshot, background, format) }
                message = "Imagen exportada"
            } catch (t: Throwable) {
                message = "No se pudo exportar la imagen."
            } finally {
                snapshot.recycle()
                busy = false
            }
        }
    }

    fun importImage(uri: Uri) {
        if (busy) return
        busy = true
        val resolver = getApplication<Application>().contentResolver
        viewModelScope.launch {
            try {
                val bmp = withContext(Dispatchers.IO) { ImageImporter.decode(resolver, uri) }
                val name = "Imagen " + SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date())
                attach(DrawingEngine(bmp.width, bmp.height, Color.WHITE, bmp), storage.newId(), name, System.currentTimeMillis(), false)
                dirty = true
            } catch (e: ImportException) {
                message = e.message
            } catch (e: OutOfMemoryError) {
                message = "Memoria insuficiente para importar esta imagen."
            } catch (e: Exception) {
                message = "No se pudo importar la imagen."
            } finally {
                busy = false
            }
        }
    }

    fun renameProject(p: ProjectSummary, newName: String) {
        val name = newName.trim().take(60)
        if (name.isEmpty()) {
            message = "El nombre no puede estar vacío."
            return
        }
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { storage.copyWithName(p.id, p.id, name) }
                refreshProjects()
            } catch (e: Exception) {
                message = "No se pudo renombrar. El archivo original no se modificó."
            }
        }
    }

    fun duplicateProject(p: ProjectSummary) {
        viewModelScope.launch {
            try {
                withContext(Dispatchers.IO) { storage.copyWithName(p.id, storage.newId(), "${p.name} (copia)".take(60)) }
                refreshProjects()
                message = "Dibujo duplicado"
            } catch (e: Exception) {
                message = "No se pudo duplicar el dibujo."
            }
        }
    }

    fun closeEditor() {
        engine?.release()
        engine = null
        projectId = null
        dirty = false
        screen = Screen.GALLERY
        refreshProjects()
    }

    fun deleteProject(summary: ProjectSummary) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) { storage.delete(summary.id) }
            refreshProjects()
        }
    }
}
