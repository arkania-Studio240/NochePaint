package com.elnoche.studio.app.navigation

enum class Screen { GALLERY, EDITOR }
