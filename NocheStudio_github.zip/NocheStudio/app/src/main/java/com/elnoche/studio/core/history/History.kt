package com.elnoche.studio.core.history

interface HistoryEntry {
    val sizeBytes: Long
}

class History(
    private val maxBytes: Long = 96L * 1024 * 1024,
    private val maxSteps: Int = 100
) {
    private val undoStack = ArrayDeque<HistoryEntry>()
    private val redoStack = ArrayDeque<HistoryEntry>()
    private var totalBytes = 0L

    val canUndo: Boolean get() = undoStack.isNotEmpty()
    val canRedo: Boolean get() = redoStack.isNotEmpty()
    val undoCount: Int get() = undoStack.size

    fun push(entry: HistoryEntry) {
        redoStack.forEach { totalBytes -= it.sizeBytes }
        redoStack.clear()
        undoStack.addLast(entry)
        totalBytes += entry.sizeBytes
        while ((totalBytes > maxBytes || undoStack.size > maxSteps) && undoStack.size > 1) {
            totalBytes -= undoStack.removeFirst().sizeBytes
        }
    }

    fun popUndo(): HistoryEntry? = undoStack.removeLastOrNull()?.also { redoStack.addLast(it) }

    fun popRedo(): HistoryEntry? = redoStack.removeLastOrNull()?.also { undoStack.addLast(it) }

    fun clear() {
        undoStack.clear()
        redoStack.clear()
        totalBytes = 0L
    }
}
