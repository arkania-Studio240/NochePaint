package com.elnoche.studio

import android.graphics.Color
import android.util.Log
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.elnoche.studio.core.drawing.BrushType
import com.elnoche.studio.core.drawing.DrawingEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class DrawingEngineTest {

    private fun alphaAt(e: DrawingEngine, x: Int, y: Int) = Color.alpha(e.bitmap.getPixel(x, y))

    @Test
    fun drawEraseUndoRedo() {
        val e = DrawingEngine(512, 512, Color.WHITE)
        e.type = BrushType.BRUSH
        e.size = 20f
        e.beginStroke(100f, 100f, 1f)
        e.moveStroke(200f, 100f, 1f)
        e.endStroke()
        assertTrue(alphaAt(e, 150, 100) > 0)

        e.type = BrushType.ERASER
        e.beginStroke(100f, 100f, 1f)
        e.moveStroke(200f, 100f, 1f)
        e.endStroke()
        assertEquals(0, alphaAt(e, 150, 100))

        e.undo()
        assertTrue(alphaAt(e, 150, 100) > 0)
        e.undo()
        assertEquals(0, alphaAt(e, 150, 100))
        e.redo()
        assertTrue(alphaAt(e, 150, 100) > 0)
    }

    @Test
    fun opacityIsAppliedOncePerStroke() {
        val e = DrawingEngine(256, 256, Color.WHITE)
        e.type = BrushType.BRUSH
        e.size = 30f
        e.opacity = 0.5f
        e.beginStroke(50f, 50f, 1f)
        e.moveStroke(150f, 50f, 1f)
        e.moveStroke(50f, 50f, 1f)
        e.endStroke()
        val a = alphaAt(e, 100, 50)
        assertTrue("alpha=$a", a in 120..135)
    }

    @Test
    fun strokePerformance() {
        for (side in intArrayOf(1080, 2048, 4096)) {
            try {
                val e = DrawingEngine(side, side, Color.WHITE)
                e.size = 24f
                val start = System.nanoTime()
                e.beginStroke(10f, 10f, 1f)
                for (i in 1..1000) {
                    e.moveStroke(10f + i * (side - 20f) / 1000f, 10f + (i % 100) * 5f, 1f)
                }
                e.endStroke()
                val ms = (System.nanoTime() - start) / 1_000_000
                Log.i("NochePerf", "lienzo ${side}x$side: 1000 puntos en $ms ms")
                e.release()
            } catch (oom: OutOfMemoryError) {
                Log.w("NochePerf", "lienzo ${side}x$side: sin memoria")
            }
        }
    }
}
