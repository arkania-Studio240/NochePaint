package com.elnoche.studio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.elnoche.studio.core.storage.ProjectFormatException
import com.elnoche.studio.core.storage.ProjectStorage
import com.elnoche.studio.feature.export.ExportFormat
import com.elnoche.studio.feature.export.ImageExporter
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import java.io.File

@RunWith(AndroidJUnit4::class)
class StorageAndExportTest {

    private val ctx = ApplicationProvider.getApplicationContext<Context>()
    private val storage = ProjectStorage(ctx)

    private fun sample(): Bitmap =
        Bitmap.createBitmap(128, 128, Bitmap.Config.ARGB_8888).apply { setPixel(10, 10, Color.RED) }

    @Test
    fun saveLoadRenameAndDuplicate() {
        val id = storage.newId()
        storage.save(id, "Prueba", 128, 128, -1, 1L, sample())
        val loaded = storage.load(storage.fileFor(id))
        assertEquals("Prueba", loaded.manifest.name)
        assertEquals(Color.RED, loaded.bitmap.getPixel(10, 10))

        storage.copyWithName(id, id, "Nuevo")
        val renamed = storage.load(storage.fileFor(id))
        assertEquals("Nuevo", renamed.manifest.name)
        assertEquals(Color.RED, renamed.bitmap.getPixel(10, 10))

        val copyId = storage.newId()
        storage.copyWithName(id, copyId, "Copia")
        assertEquals("Copia", storage.load(storage.fileFor(copyId)).manifest.name)

        storage.delete(id)
        storage.delete(copyId)
    }

    @Test(expected = ProjectFormatException::class)
    fun invalidFileIsRejectedAndKept() {
        val f = storage.fileFor("invalido-test")
        f.writeText("esto no es un zip")
        try {
            storage.load(f)
        } finally {
            assertTrue(f.exists())
            f.delete()
        }
    }

    @Test
    fun pngKeepsTransparencyAndJpegIsOpaque() {
        val png = File(ctx.cacheDir, "t.png")
        val jpg = File(ctx.cacheDir, "t.jpg")
        ImageExporter.write(ctx.contentResolver, Uri.fromFile(png), sample().copy(Bitmap.Config.ARGB_8888, true), 0, ExportFormat.PNG)
        ImageExporter.write(ctx.contentResolver, Uri.fromFile(jpg), sample().copy(Bitmap.Config.ARGB_8888, true), 0, ExportFormat.JPEG)
        assertEquals(0, Color.alpha(BitmapFactory.decodeFile(png.path).getPixel(50, 50)))
        assertEquals(255, Color.alpha(BitmapFactory.decodeFile(jpg.path).getPixel(50, 50)))
        png.delete()
        jpg.delete()
    }
}
